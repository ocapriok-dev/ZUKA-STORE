export type PaymentMethodId = 'qris' | 'dana' | 'gopay' | 'ovo' | 'bca' | 'mandiri';

export interface PaymentMethod {
  id: PaymentMethodId;
  name: string;
  type: 'E-Wallet' | 'QRIS' | 'Bank Transfer';
  logo: string;
  accountNumber?: string;
  accountName?: string;
  instructions: string[];
}

export type OrderStatus = 'PENDING' | 'PAID' | 'DELIVERED' | 'CANCELLED';

export interface Order {
  id: string;
  growId: string;
  worldName: string;
  quantity: number;
  pricePerDgl: number;
  totalPrice: number;
  paymentMethod: PaymentMethodId;
  status: OrderStatus;
  createdAt: string;
  deliveryMethod: 'donation_box' | 'trade';
  contact: string;
  notes?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  rating: number;
  comment: string;
  growId: string;
  date: string;
  quantity: number;
}

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, Star, HelpCircle, MessageSquareCode, Award, ShieldAlert, Heart, RefreshCw } from 'lucide-react';

import { Order, Testimonial } from './types';
import { PAYMENT_METHODS, PRICE_PER_DGL, INITIAL_TESTIMONIALS, generateOrderId, formatRupiah } from './utils/payment';

import { RGBWrapper } from './components/RGBWrapper';
import { ZukaLogo } from './components/ZukaLogo';
import { DGLProductCard } from './components/DGLProductCard';
import { CheckoutForm } from './components/CheckoutForm';
import { OrderReceipt } from './components/OrderReceipt';
import { AdminPanel } from './components/AdminPanel';
import { Testimonials } from './components/Testimonials';

import { 
  subscribeToOrders, 
  createFirestoreOrder, 
  updateFirestoreOrderStatus, 
  deleteFirestoreOrder, 
  subscribeToConfig, 
  saveStoreConfig 
} from './lib/firebase';

export default function App() {
  const [quantity, setQuantity] = useState<number>(1);
  const [screen, setScreen] = useState<'PRODUCT' | 'CHECKOUT' | 'RECEIPT'>('PRODUCT');
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  
  // Testimonials state
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);

  // Dynamic Product Settings Configuration
  const [pricePerDgl, setPricePerDgl] = useState<number>(27000);
  const [productImage, setProductImage] = useState<string>('/src/assets/images/diamond_gem_lock_1783066536389.jpg');
  const [stockAmount, setStockAmount] = useState<number>(524);
  const [qrisQrCode, setQrisQrCode] = useState<string>('');
  const [adminPassword, setAdminPassword] = useState<string>('admin');

  const handlePriceChange = async (newPrice: number) => {
    setPricePerDgl(newPrice);
    try {
      await saveStoreConfig({ pricePerDgl: newPrice });
    } catch (e) {
      console.error("Gagal menyimpan harga ke Firestore:", e);
    }
  };

  const handleProductImageChange = async (newUrl: string) => {
    setProductImage(newUrl);
    try {
      await saveStoreConfig({ productImage: newUrl });
    } catch (e) {
      console.error("Gagal menyimpan foto produk ke Firestore:", e);
    }
  };

  const handleStockChange = async (newStock: number) => {
    setStockAmount(newStock);
    try {
      await saveStoreConfig({ stockAmount: newStock });
    } catch (e) {
      console.error("Gagal menyimpan stok ke Firestore:", e);
    }
  };

  const handleQrisQrChange = async (newUrl: string) => {
    setQrisQrCode(newUrl);
    try {
      await saveStoreConfig({ qrisQrCode: newUrl });
    } catch (e) {
      console.error("Gagal menyimpan QRIS ke Firestore:", e);
    }
  };

  const handleAdminPasswordChange = async (newPass: string) => {
    setAdminPassword(newPass);
    try {
      await saveStoreConfig({ adminPassword: newPass });
    } catch (e) {
      console.error("Gagal menyimpan sandi admin ke Firestore:", e);
    }
  };

  // Load config & orders from Firestore, and testimonials from localStorage on mount
  useEffect(() => {
    // 1. Subscribe to Live Config from Firestore
    const unsubscribeConfig = subscribeToConfig((config) => {
      if (config.pricePerDgl !== undefined) setPricePerDgl(config.pricePerDgl);
      if (config.productImage !== undefined) setProductImage(config.productImage);
      if (config.stockAmount !== undefined) setStockAmount(config.stockAmount);
      if (config.qrisQrCode !== undefined) setQrisQrCode(config.qrisQrCode);
      if (config.adminPassword !== undefined) setAdminPassword(config.adminPassword);
    });

    // 2. Subscribe to Live Orders from Firestore
    const unsubscribeOrders = subscribeToOrders((updatedOrders) => {
      setOrders(updatedOrders);
    });

    // 3. Testimonials
    const storedTestis = localStorage.getItem('zuka_store_testimonials');
    if (storedTestis) {
      try {
        setTestimonials(JSON.parse(storedTestis));
      } catch (e) {
        console.error(e);
      }
    } else {
      // Preload initial mock reviews from previous BGL trades
      const defaultTestis: Testimonial[] = [
        {
          id: 'testi-1',
          name: 'Adrian Pratama',
          growId: 'RizkyGT',
          rating: 5,
          comment: 'Mantap banget gan! Beli 5 DGL langsung ditaruh di donation box gak sampe 3 menit. ZUKA Store emang paling cepet se-Dreamtopia PS!',
          date: '02/07/2026',
          quantity: 5
        },
        {
          id: 'testi-2',
          name: 'Kevin Wijaya',
          growId: 'Valkyrie01',
          rating: 5,
          comment: 'Awalnya ragu karna harga murah banget cuma 27k, ternyata beneran aman dan admin ramah. Sangat direkomendasikan buat player Dreamtopia PS!',
          date: '01/07/2026',
          quantity: 12
        },
        {
          id: 'testi-3',
          name: 'Siti Rahma',
          growId: 'BintangJaya',
          rating: 4,
          comment: 'Proses pengiriman cepet, respon wa admin jg gercep. Makasih ya nanti order lagi disini.',
          date: '29/06/2026',
          quantity: 2
        },
        {
          id: 'testi-4',
          name: 'Hendrik',
          growId: 'WelsonGT',
          rating: 5,
          comment: 'Udah langganan beli DGL di Zuka. Selalu puas ama servicenya. Terpercaya 100%.',
          date: '28/06/2026',
          quantity: 30
        }
      ];
      setTestimonials(defaultTestis);
      localStorage.setItem('zuka_store_testimonials', JSON.stringify(defaultTestis));
    }

    return () => {
      unsubscribeConfig();
      unsubscribeOrders();
    };
  }, []);

  // Sync active order with live orders list to receive real-time status updates from Admin
  useEffect(() => {
    if (activeOrder) {
      const match = orders.find((o) => o.id === activeOrder.id);
      if (match && match.status !== activeOrder.status) {
        setActiveOrder(match);
      }
    }
  }, [orders, activeOrder]);

  const handleCheckoutSubmit = async (formData: {
    growId: string;
    worldName: string;
    deliveryMethod: 'donation_box' | 'trade';
    paymentMethod: any;
    contact: string;
    notes?: string;
  }) => {
    const newOrderData: Omit<Order, 'id'> = {
      growId: formData.growId,
      worldName: formData.worldName,
      quantity: quantity,
      pricePerDgl: pricePerDgl,
      totalPrice: quantity * pricePerDgl,
      paymentMethod: formData.paymentMethod,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
      deliveryMethod: formData.deliveryMethod,
      contact: formData.contact,
      notes: formData.notes
    };

    try {
      const docId = await createFirestoreOrder(newOrderData);
      const fullOrder: Order = { id: docId, ...newOrderData };
      setActiveOrder(fullOrder);
      setScreen('RECEIPT');
    } catch (error) {
      console.error("Gagal memproses checkout ke Firestore:", error);
      alert("Gagal memproses pesanan. Silakan coba lagi.");
    }
  };

  const handleOrderStatusChange = async (orderId: string, status: Order['status']) => {
    try {
      await updateFirestoreOrderStatus(orderId, status);
    } catch (e) {
      console.error("Gagal mengupdate status pesanan di Firestore:", e);
    }
  };

  const handleDeleteOrder = async (orderId: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus catatan pesanan ini?')) {
      try {
        await deleteFirestoreOrder(orderId);
        if (activeOrder && activeOrder.id === orderId) {
          setActiveOrder(null);
          setScreen('PRODUCT');
        }
      } catch (e) {
        console.error("Gagal menghapus pesanan dari Firestore:", e);
      }
    }
  };

  const handleAddTestimonial = (newTesti: Omit<Testimonial, 'id' | 'date'>) => {
    const testi: Testimonial = {
      ...newTesti,
      id: `testi-${Date.now()}`,
      date: new Date().toLocaleDateString('id-ID')
    };
    const updated = [testi, ...testimonials];
    setTestimonials(updated);
    localStorage.setItem('zuka_store_testimonials', JSON.stringify(updated));
  };

  const handleNewOrder = () => {
    setActiveOrder(null);
    setScreen('PRODUCT');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans overflow-x-hidden scanlines relative cyber-grid">
      
      {/* Background neon light shapes */}
      <div className="absolute top-[10%] left-[5%] w-80 h-80 bg-cyan-500/10 rounded-full blur-[100px] pointer-events-none animate-pulse" />
      <div className="absolute top-[40%] right-[10%] w-96 h-96 bg-purple-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[10%] left-[20%] w-80 h-80 bg-blue-500/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Top Notification Warning Bar (Common in game shops for alerts/events) */}
      <div className="bg-gradient-to-r from-blue-950 via-cyan-950 to-purple-950 text-cyan-300 py-2 px-4 border-b border-cyan-500/20 text-center text-xs font-mono flex items-center justify-center gap-2 relative z-30">
        <span className="flex h-2 w-2 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
        </span>
        <span>🔥 PROMO BULAN INI: DGL hanya {formatRupiah(pricePerDgl)} / Lock! Garansi pengiriman instan 5 menit lunas langsung didrop! 🔥</span>
      </div>

      {/* Main Header Container */}
      <header className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 relative z-30">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <ZukaLogo />

          {/* Quick Stats Nav */}
          <div className="flex flex-wrap items-center gap-3 bg-slate-900/50 backdrop-blur-md px-4 py-2.5 rounded-full border border-white/5 text-xs font-medium text-gray-400">
            <span className="flex items-center gap-1.5 text-cyan-400 font-bold">
              <ShoppingBag size={14} />
              <span>ZUKA DGL Store</span>
            </span>
            <span className="text-gray-700">|</span>
            <span className="flex items-center gap-1 text-emerald-400 font-semibold">
              <Star size={12} className="fill-emerald-400 text-emerald-400" />
              <span>4.9/5.0 Rating</span>
            </span>
            <span className="text-gray-700">|</span>
            <span className="text-gray-300">Stok: {stockAmount} DGL Ready</span>
          </div>
        </div>
      </header>

      {/* Core Main Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 space-y-10 relative z-20">
        
        {/* Dynamic Screen/Container Frame */}
        <RGBWrapper id="main-store-frame">
          <AnimatePresence mode="wait">
            {screen === 'PRODUCT' && (
              <motion.div
                key="product"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.3 }}
              >
                <DGLProductCard
                  quantity={quantity}
                  onQuantityChange={setQuantity}
                  onCheckoutClick={() => setScreen('CHECKOUT')}
                  pricePerDgl={pricePerDgl}
                  productImage={productImage}
                  stockAmount={stockAmount}
                />
              </motion.div>
            )}

            {screen === 'CHECKOUT' && (
              <motion.div
                key="checkout"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.3 }}
              >
                <CheckoutForm
                  quantity={quantity}
                  onBackClick={() => setScreen('PRODUCT')}
                  onSubmit={handleCheckoutSubmit}
                  pricePerDgl={pricePerDgl}
                />
              </motion.div>
            )}

            {screen === 'RECEIPT' && activeOrder && (
              <motion.div
                key="receipt"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
              >
                <OrderReceipt
                  order={activeOrder}
                  onStatusChange={handleOrderStatusChange}
                  onNewOrderClick={handleNewOrder}
                  qrisQrCode={qrisQrCode}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </RGBWrapper>

        {/* Info & Trust Cards (Bento-grid styled row) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <RGBWrapper subtle id="trust-card-1">
            <div className="space-y-2 text-center sm:text-left">
              <div className="mx-auto sm:mx-0 h-10 w-10 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex items-center justify-center">
                <Award size={20} className="animate-pulse" />
              </div>
              <h4 className="text-sm font-extrabold text-white">Garansi 100% Amanah</h4>
              <p className="text-xs text-gray-400 leading-relaxed">
                Kami menjamin keamanan transaksi DGL Anda 100%. Tidak ada risiko ban/hack. Transaksi legal & tepercaya di komunitas Dreamtopia PS.
              </p>
            </div>
          </RGBWrapper>

          <RGBWrapper subtle id="trust-card-2">
            <div className="space-y-2 text-center sm:text-left">
              <div className="mx-auto sm:mx-0 h-10 w-10 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center justify-center">
                <RefreshCw size={18} className="animate-spin" style={{ animationDuration: '6s' }} />
              </div>
              <h4 className="text-sm font-extrabold text-white">Pengiriman Kilat</h4>
              <p className="text-xs text-gray-400 leading-relaxed">
                Pesanan Anda diproses kurang dari 5 menit setelah pembayaran terverifikasi. Kurir kami langsung mengantarkan ke World tujuan Anda!
              </p>
            </div>
          </RGBWrapper>

          <RGBWrapper subtle id="trust-card-3">
            <div className="space-y-2 text-center sm:text-left">
              <div className="mx-auto sm:mx-0 h-10 w-10 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center justify-center">
                <HelpCircle size={20} />
              </div>
              <h4 className="text-sm font-extrabold text-white">Bantuan CS 24/7</h4>
              <p className="text-xs text-gray-400 leading-relaxed">
                Mengalami masalah saat bertransaksi? Hubungi layanan dukungan WhatsApp atau Discord kami kapan pun Anda membutuhkan bantuan.
              </p>
            </div>
          </RGBWrapper>
        </div>

        {/* Interactive Reviews / Testimonials Section */}
        <RGBWrapper subtle id="reviews-frame">
          <Testimonials
            testimonials={testimonials}
            onAddTestimonial={handleAddTestimonial}
          />
        </RGBWrapper>

        {/* Floating/Bottom Admin Console Tray */}
        <AdminPanel
          orders={orders}
          onStatusChange={handleOrderStatusChange}
          onDeleteOrder={handleDeleteOrder}
          pricePerDgl={pricePerDgl}
          onPriceChange={handlePriceChange}
          productImage={productImage}
          onProductImageChange={handleProductImageChange}
          stockAmount={stockAmount}
          onStockChange={handleStockChange}
          qrisQrCode={qrisQrCode}
          onQrisQrChange={handleQrisQrChange}
          adminPassword={adminPassword}
          onAdminPasswordChange={handleAdminPasswordChange}
        />
      </main>

      {/* Bottom Footer Details */}
      <footer className="border-t border-white/5 bg-slate-950/80 backdrop-blur-md py-12 relative z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="text-center md:text-left space-y-1">
              <div className="flex items-center justify-center md:justify-start gap-1.5 text-cyan-400 font-black font-sans text-lg tracking-wider">
                <span>ZUKA</span>
                <span className="text-xs font-normal text-gray-500 uppercase tracking-widest bg-slate-900 px-1.5 py-0.5 rounded border border-white/5">STORE</span>
              </div>
              <p className="text-[11px] text-gray-500">
                Penyedia DGL Dreamtopia PS Terpercaya dengan Pengiriman Tercepat & Harga Termurah.
              </p>
            </div>

            <div className="flex items-center gap-1.5 text-[11px] text-gray-500 font-mono">
              <span>Made with</span>
              <Heart size={10} className="text-rose-500 fill-rose-500 animate-pulse" />
              <span>for Dreamtopia PS Gamers. © 2026 ZUKA Store. All Rights Reserved.</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

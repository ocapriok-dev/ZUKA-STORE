import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  addDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  getDoc,
  query,
  orderBy
} from 'firebase/firestore';
import { Order } from '../types';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const db = getFirestore(app);

// Collection references
const ordersCollection = collection(db, 'orders');
const configDocRef = doc(db, 'config', 'store');

export interface StoreConfig {
  pricePerDgl: number;
  productImage: string;
  stockAmount: number;
  qrisQrCode: string;
  adminPassword?: string;
}

const DEFAULT_CONFIG: StoreConfig = {
  pricePerDgl: 27000,
  productImage: '/src/assets/images/diamond_gem_lock_1783066536389.jpg',
  stockAmount: 524,
  qrisQrCode: '',
  adminPassword: 'admin' // Default password is 'admin'
};

/**
 * Subscribe to live orders list from Firestore
 */
export const subscribeToOrders = (onUpdate: (orders: Order[]) => void) => {
  const q = query(ordersCollection, orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const orders: Order[] = [];
    snapshot.forEach((doc) => {
      orders.push({ id: doc.id, ...doc.data() } as Order);
    });
    onUpdate(orders);
  }, (error) => {
    console.error("Error subscribing to orders:", error);
  });
};

/**
 * Add a new order to Firestore
 */
export const createFirestoreOrder = async (order: Omit<Order, 'id'>): Promise<string> => {
  try {
    const docRef = await addDoc(ordersCollection, order);
    return docRef.id;
  } catch (error) {
    console.error("Error adding order to Firestore:", error);
    throw error;
  }
};

/**
 * Update an existing order status
 */
export const updateFirestoreOrderStatus = async (orderId: string, status: Order['status']): Promise<void> => {
  try {
    const orderDocRef = doc(db, 'orders', orderId);
    await updateDoc(orderDocRef, { status });
  } catch (error) {
    console.error("Error updating order status in Firestore:", error);
    throw error;
  }
};

/**
 * Delete an order from Firestore
 */
export const deleteFirestoreOrder = async (orderId: string): Promise<void> => {
  try {
    const orderDocRef = doc(db, 'orders', orderId);
    await deleteDoc(orderDocRef);
  } catch (error) {
    console.error("Error deleting order from Firestore:", error);
    throw error;
  }
};

/**
 * Subscribe to live store configuration from Firestore
 */
export const subscribeToConfig = (onUpdate: (config: StoreConfig) => void) => {
  return onSnapshot(configDocRef, async (snapshot) => {
    if (snapshot.exists()) {
      const data = snapshot.data() as StoreConfig;
      onUpdate({
        ...DEFAULT_CONFIG,
        ...data
      });
    } else {
      // If doc doesn't exist, initialize it with default values
      try {
        await setDoc(configDocRef, DEFAULT_CONFIG);
        onUpdate(DEFAULT_CONFIG);
      } catch (err) {
        console.error("Failed to initialize default config:", err);
        onUpdate(DEFAULT_CONFIG);
      }
    }
  }, async (error) => {
    console.error("Error subscribing to config:", error);
    // In case of permission errors (rules not deployed yet), fetch local or default
    onUpdate(DEFAULT_CONFIG);
  });
};

/**
 * Save store configuration to Firestore
 */
export const saveStoreConfig = async (newConfig: Partial<StoreConfig>): Promise<void> => {
  try {
    await setDoc(configDocRef, newConfig, { merge: true });
  } catch (error) {
    console.error("Error saving store config to Firestore:", error);
    throw error;
  }
};

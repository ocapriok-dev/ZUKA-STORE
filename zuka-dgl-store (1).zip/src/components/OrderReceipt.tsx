import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Check, Copy, AlertCircle, RefreshCw, Sparkles, MapPin, PhoneCall, Gift, CheckCircle2, UploadCloud, Trash2, Image as ImageIcon } from 'lucide-react';
import { Order } from '../types';
import { formatRupiah, PAYMENT_METHODS, ADMIN_WA_NUMBER } from '../utils/payment';

interface OrderReceiptProps {
  order: Order;
  onStatusChange: (orderId: string, status: Order['status']) => void;
  onNewOrderClick: () => void;
  qrisQrCode?: string;
}

export const OrderReceipt: React.FC<OrderReceiptProps> = ({
  order,
  onStatusChange,
  onNewOrderClick,
  qrisQrCode = ''
}) => {
  const [copied, setCopied] = useState(false);
  const [simulating, setSimulating] = useState(false);
  const [deliveryStep, setDeliveryStep] = useState(0);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const selectedPayment = PAYMENT_METHODS.find((p) => p.id === order.paymentMethod);

  // Auto-progress delivery simulation if order is paid
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (order.status === 'PAID') {
      setDeliveryStep(1);
      timer = setTimeout(() => {
        setDeliveryStep(2);
        const deliverTimer = setTimeout(() => {
          setDeliveryStep(3);
          onStatusChange(order.id, 'DELIVERED');
        }, 5000);
        return () => clearTimeout(deliverTimer);
      }, 4000);
    } else if (order.status === 'DELIVERED') {
      setDeliveryStep(3);
    } else {
      setDeliveryStep(0);
    }
    return () => clearTimeout(timer);
  }, [order.status, order.id]);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSimulatePayment = () => {
    setSimulating(true);
    setTimeout(() => {
      onStatusChange(order.id, 'PAID');
      setSimulating(false);
    }, 1500);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const removePreview = () => {
    setPreviewUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleConfirmWhatsApp = () => {
    const deliveryMethodLabel = order.deliveryMethod === 'donation_box' ? '📦 Donation Box' : '🤝 Trade In-Game';
    const noteText = order.notes ? `\n*Catatan:* ${order.notes}` : '';
    
    const message = `Halo Admin ZUKA Store! 🌟\n` +
      `Saya ingin mengonfirmasi pembayaran untuk pembelian DGL.\n\n` +
      `*─── RINCIAN PESANAN ───*\n` +
      `*Invoice ID:* ${order.id}\n` +
      `*GrowID:* ${order.growId}\n` +
      `*World Name:* ${order.worldName}\n` +
      `*Jumlah:* ${order.quantity} DGL\n` +
      `*Metode Pengiriman:* ${deliveryMethodLabel}\n` +
      `*Total Bayar:* ${formatRupiah(order.totalPrice)}\n` +
      `*Metode Pembayaran:* ${selectedPayment?.name || order.paymentMethod}\n` +
      `*Kontak:* ${order.contact}${noteText}\n\n` +
      `*────────────────────*\n` +
      `Berikut saya lampirkan foto bukti transfer/pembayaran saya. Mohon segera diproses & dikirim ya min! Terima kasih. 🙏🔥`;
      
    const waUrl = `https://wa.me/${ADMIN_WA_NUMBER}?text=${encodeURIComponent(message)}`;
    
    // Open WhatsApp in a new tab/window
    window.open(waUrl, '_blank');
    
    // Auto-progress status in our app so they see real-time updates and logs
    onStatusChange(order.id, 'PAID');
  };

  // Generate a mock QR content inside SVG
  const renderMockQR = () => {
    return (
      <div className="relative p-3 bg-white rounded-lg flex flex-col items-center justify-center border-4 border-slate-900 shadow-md">
        {/* QRIS Header branding */}
        <div className="w-full flex justify-between items-center bg-rose-600 text-white text-[8px] font-black px-1 py-0.5 rounded-t mb-2">
          <span>QRIS</span>
          <span>DANA/OVO/GOPAY</span>
        </div>
        
        {/* Mock QR matrix using styled grid */}
        <div className="grid grid-cols-5 gap-1.5 w-36 h-36 bg-white p-1">
          {/* Top Left Finder pattern */}
          <div className="col-span-2 row-span-2 bg-slate-900 rounded p-0.5">
            <div className="w-full h-full bg-white rounded flex items-center justify-center">
              <div className="w-1/2 h-1/2 bg-slate-900 rounded-sm"></div>
            </div>
          </div>
          <div className="bg-slate-900 rounded-sm"></div>
          {/* Top Right Finder pattern */}
          <div className="col-span-2 row-span-2 bg-slate-900 rounded p-0.5">
            <div className="w-full h-full bg-white rounded flex items-center justify-center">
              <div className="w-1/2 h-1/2 bg-slate-900 rounded-sm"></div>
            </div>
          </div>
          {/* Middle fillers */}
          <div className="bg-slate-900 rounded-sm"></div>
          <div className="bg-slate-900 rounded-sm"></div>
          <div className="bg-slate-900 rounded-sm"></div>
          <div className="bg-slate-900 rounded-sm"></div>
          <div className="bg-slate-900 rounded-sm"></div>
          <div className="bg-slate-900 rounded-sm"></div>
          {/* Bottom Left Finder pattern */}
          <div className="col-span-2 row-span-2 bg-slate-900 rounded p-0.5">
            <div className="w-full h-full bg-white rounded flex items-center justify-center">
              <div className="w-1/2 h-1/2 bg-slate-900 rounded-sm"></div>
            </div>
          </div>
          <div className="bg-slate-900 rounded-sm"></div>
          <div className="bg-slate-900 rounded-sm"></div>
          <div className="bg-slate-900 rounded-sm"></div>
          <div className="bg-slate-900 rounded-sm"></div>
          <div className="bg-slate-900 rounded-sm"></div>
        </div>
        
        {/* Center Logo placeholder */}
        <div className="absolute inset-0 m-auto w-8 h-8 bg-white border-2 border-slate-900 rounded-md flex items-center justify-center z-10 shadow">
          <span className="text-[7px] font-black font-sans text-cyan-600">ZUKA</span>
        </div>

        <span className="text-[9px] font-bold text-gray-500 mt-2">NMID: ID1029239123</span>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Dynamic Status Banner */}
      <div className={`p-5 rounded-xl border text-center relative overflow-hidden ${
        order.status === 'DELIVERED'
          ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
          : order.status === 'PAID'
          ? 'bg-blue-950/20 border-blue-500/40 text-blue-300'
          : 'bg-amber-950/20 border-amber-500/40 text-amber-300'
      }`}>
        <div className="absolute top-0 right-0 p-1.5 opacity-10">
          <Sparkles size={120} />
        </div>
        
        <h3 className="text-lg font-black tracking-wide uppercase font-mono">
          {order.status === 'DELIVERED' && '🎉 PESANAN SELESAI & DIKIRIM'}
          {order.status === 'PAID' && '⚡ PEMBAYARAN DIKONFIRMASI'}
          {order.status === 'PENDING' && '⌛ MENUNGGU PEMBAYARAN'}
        </h3>
        <p className="text-xs mt-1 font-sans opacity-90 max-w-lg mx-auto">
          {order.status === 'DELIVERED' && `DGL Anda telah sukses diantarkan ke World ${order.worldName}! Terima kasih telah belanja di ZUKA.`}
          {order.status === 'PAID' && `Dana diterima! Admin sedang bersiap mengantar ${order.quantity} DGL ke world ${order.worldName}. Mohon tunggu sebentar.`}
          {order.status === 'PENDING' && 'Silakan selesaikan pembayaran di bawah ini agar pesanan Anda dapat segera kami proses.'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Column: Invoice Details */}
        <div className="md:col-span-7 space-y-4">
          <div className="p-5 rounded-xl bg-slate-900/40 border border-white/5 space-y-4">
            <div className="flex justify-between items-center border-b border-white/5 pb-3">
              <span className="text-xs font-mono text-gray-400">INVOICE ID:</span>
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-sm font-bold text-cyan-400">{order.id}</span>
                <button
                  onClick={() => handleCopy(order.id)}
                  className="text-gray-500 hover:text-white transition-colors cursor-pointer"
                >
                  {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                </button>
              </div>
            </div>

            {/* Order specs */}
            <div className="grid grid-cols-2 gap-y-3.5 gap-x-2 text-xs">
              <div>
                <span className="text-gray-400 block mb-0.5">GrowID Pembeli:</span>
                <span className="font-mono font-bold text-white text-sm">{order.growId}</span>
              </div>
              <div>
                <span className="text-gray-400 block mb-0.5">World Name:</span>
                <span className="font-mono font-bold text-white text-sm flex items-center gap-1">
                  <MapPin size={12} className="text-cyan-400" />
                  {order.worldName}
                </span>
              </div>
              <div>
                <span className="text-gray-400 block mb-0.5">Jumlah DGL:</span>
                <span className="font-mono font-bold text-white text-sm bg-cyan-500/10 text-cyan-400 px-2 py-0.5 rounded border border-cyan-500/20 inline-block">
                  {order.quantity} DGL
                </span>
              </div>
              <div>
                <span className="text-gray-400 block mb-0.5">Metode Pengiriman:</span>
                <span className="font-sans font-bold text-white">
                  {order.deliveryMethod === 'donation_box' ? '📦 Donation Box' : '🤝 Trade In-Game'}
                </span>
              </div>
              <div>
                <span className="text-gray-400 block mb-0.5">Kontak Pembeli:</span>
                <span className="font-sans font-medium text-gray-200">{order.contact}</span>
              </div>
              <div>
                <span className="text-gray-400 block mb-0.5">Metode Pembayaran:</span>
                <span className="font-sans font-bold text-white flex items-center gap-1.5">
                  <img
                    src={selectedPayment?.logo}
                    alt={selectedPayment?.name}
                    className="h-4 max-w-[40px] object-contain inline"
                    referrerPolicy="no-referrer"
                  />
                  {selectedPayment?.name.split(' ')[0]}
                </span>
              </div>
            </div>

            {order.notes && (
              <div className="p-3 rounded bg-slate-950/40 border border-white/5 text-xs text-gray-400 font-sans">
                <span className="font-semibold text-gray-300 block mb-0.5">Catatan Anda:</span>
                "{order.notes}"
              </div>
            )}

            <div className="border-t border-white/5 pt-3 flex justify-between items-center">
              <span className="text-sm font-bold text-white">Total Tagihan:</span>
              <span className="text-xl font-black text-cyan-400 font-mono">{formatRupiah(order.totalPrice)}</span>
            </div>
          </div>

          {/* Delivery progress tracking timeline */}
          {order.status !== 'PENDING' && (
            <div className="p-5 rounded-xl bg-slate-900/40 border border-white/5 space-y-4">
              <span className="text-xs font-bold text-white uppercase font-mono tracking-wider block">Status Pengantaran Live</span>
              <div className="space-y-4 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-[1px] before:bg-slate-800">
                <div className="flex items-start gap-3 relative z-10">
                  <div className={`h-6.5 w-6.5 rounded-full flex items-center justify-center border text-xs font-bold ${
                    deliveryStep >= 1 ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20' : 'bg-slate-950 border-white/10 text-gray-400'
                  }`}>
                    {deliveryStep >= 1 ? <Check size={12} className="stroke-[3]" /> : '1'}
                  </div>
                  <div>
                    <span className={`text-xs font-bold block ${deliveryStep >= 1 ? 'text-white' : 'text-gray-500'}`}>Pembayaran Terverifikasi</span>
                    <span className="text-[10px] text-gray-400 block mt-0.5">Admin mengonfirmasi dana masuk secara real-time.</span>
                  </div>
                </div>

                <div className="flex items-start gap-3 relative z-10">
                  <div className={`h-6.5 w-6.5 rounded-full flex items-center justify-center border text-xs font-bold ${
                    deliveryStep >= 2 ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20' : 'bg-slate-950 border-white/10 text-gray-400'
                  }`}>
                    {deliveryStep >= 2 ? <Check size={12} className="stroke-[3]" /> : '2'}
                  </div>
                  <div>
                    <span className={`text-xs font-bold block ${deliveryStep >= 2 ? 'text-white' : 'text-gray-500'}`}>Kurir Menuju World {order.worldName}</span>
                    <span className="text-[10px] text-gray-400 block mt-0.5">Kurir online masuk ke dalam game dan menuju world tujuan Anda.</span>
                  </div>
                </div>

                <div className="flex items-start gap-3 relative z-10">
                  <div className={`h-6.5 w-6.5 rounded-full flex items-center justify-center border text-xs font-bold ${
                    deliveryStep >= 3 ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20' : 'bg-slate-950 border-white/10 text-gray-400'
                  }`}>
                    {deliveryStep >= 3 ? <Check size={12} className="stroke-[3]" /> : '3'}
                  </div>
                  <div>
                    <span className={`text-xs font-bold block ${deliveryStep >= 3 ? 'text-white' : 'text-gray-500'}`}>Selesai di Drop / Transaksi Berhasil</span>
                    <span className="text-[10px] text-gray-400 block mt-0.5">DGL Anda sukses didrop di Donation Box world Anda atau ditrade langsung!</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Dynamic Payment Gate Display */}
        <div className="md:col-span-5 flex flex-col space-y-4">
          <div className="p-5 rounded-xl bg-slate-950/60 border border-white/10 flex flex-col items-center justify-center text-center space-y-4">
            {order.status === 'PENDING' ? (
              <>
                <span className="text-xs font-bold text-gray-400 uppercase font-mono tracking-wider">Metode Pembayaran</span>
                <span className="text-base font-bold text-white">{selectedPayment?.name}</span>

                {/* If selected payment is QRIS, render beautiful QR */}
                {order.paymentMethod === 'qris' ? (
                  qrisQrCode ? (
                    <div className="flex flex-col items-center justify-center p-3 bg-white rounded-2xl border-4 border-slate-900 shadow-xl max-w-[200px] mx-auto animate-fade-in">
                      <div className="w-full bg-rose-600 text-white text-[9px] font-black py-1 px-2 rounded-t text-center uppercase tracking-wider mb-2">
                        QRIS RESMI TOKO
                      </div>
                      <img src={qrisQrCode} alt="QRIS ZUKA Store" className="w-40 h-40 object-contain rounded-lg" referrerPolicy="no-referrer" />
                      <span className="text-[8px] font-bold text-gray-500 mt-2 font-mono">PINDAI DENGAN E-WALLET</span>
                    </div>
                  ) : (
                    renderMockQR()
                  )
                ) : (
                  // Else render Account details for Manual transfer
                  <div className="w-full space-y-3.5 p-4 rounded-xl bg-slate-900/50 border border-white/5 text-left">
                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Nomor Rekening / HP:</span>
                      <div className="flex justify-between items-center bg-slate-950 px-3 py-2.5 rounded border border-white/5 font-mono text-sm text-cyan-400 font-bold">
                        <span>{selectedPayment?.accountNumber}</span>
                        <button
                          onClick={() => handleCopy(selectedPayment?.accountNumber || '')}
                          className="text-gray-500 hover:text-white transition-colors cursor-pointer flex items-center gap-1 text-[11px]"
                        >
                          <Copy size={11} /> Salin
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Atas Nama (A/N):</span>
                      <span className="text-xs font-bold text-white block bg-slate-950/30 px-3 py-1.5 rounded border border-white/5">{selectedPayment?.accountName}</span>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Jumlah Transfer Pas:</span>
                      <span className="text-base font-black text-emerald-400 block font-mono">{formatRupiah(order.totalPrice)}</span>
                    </div>
                  </div>
                )}

                {/* Payment Instructions list */}
                <div className="w-full text-left bg-slate-900/30 p-4 rounded-lg border border-white/5 space-y-2">
                  <div className="flex items-center gap-1.5 text-cyan-400 text-xs font-semibold mb-1">
                    <AlertCircle size={14} />
                    <span>Petunjuk Transfer</span>
                  </div>
                  <ul className="text-[11px] text-gray-400 space-y-1.5 list-disc pl-4 leading-relaxed">
                    {selectedPayment?.instructions.map((inst, i) => (
                      <li key={i}>{inst}</li>
                    ))}
                  </ul>
                </div>

                {/* Upload Bukti Pembayaran Section */}
                <div className="w-full space-y-2 border-t border-white/5 pt-4">
                  <div className="flex flex-col space-y-1 text-left">
                    <span className="text-[11px] font-bold text-gray-300 uppercase font-mono tracking-wider">
                      Langkah 1: Siapkan Bukti Pembayaran
                    </span>
                    <p className="text-[10px] text-gray-500 leading-normal">
                      Silakan screenshot / foto bukti pembayaran Anda dari aplikasi E-wallet atau M-Banking, lalu unggah di bawah ini.
                    </p>
                  </div>

                  {/* Hidden Input File */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                  />

                  {/* Drag and Drop Zone / Preview */}
                  {!previewUrl ? (
                    <div
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onClick={() => fileInputRef.current?.click()}
                      className={`border border-dashed rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer transition-all ${
                        isDragging
                          ? 'border-cyan-400 bg-cyan-950/20 shadow-lg shadow-cyan-500/10'
                          : 'border-white/10 hover:border-cyan-500/40 bg-slate-900/30'
                      }`}
                    >
                      <UploadCloud size={24} className="text-gray-500 mb-1.5 animate-bounce" />
                      <span className="text-xs font-bold text-gray-300">Pilih / Seret Foto Struk</span>
                      <span className="text-[9px] text-gray-500 mt-0.5">Mendukung format PNG, JPG, JPEG</span>
                    </div>
                  ) : (
                    <div className="relative rounded-xl overflow-hidden bg-slate-900 border border-white/10 p-2">
                      <img
                        src={previewUrl}
                        alt="Bukti Transfer"
                        className="w-full max-h-40 object-contain rounded-lg"
                      />
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          removePreview();
                        }}
                        className="absolute top-3 right-3 bg-red-600/90 hover:bg-red-500 text-white p-1.5 rounded-full shadow-md transition-colors cursor-pointer"
                        title="Hapus Foto"
                      >
                        <Trash2 size={13} />
                      </button>
                      <div className="text-[10px] text-emerald-400 font-bold flex items-center justify-center gap-1 mt-1.5 bg-emerald-950/30 py-1 rounded border border-emerald-900/20">
                        <Check size={12} className="stroke-[3]" /> Bukti Pembayaran Terpilih!
                      </div>
                    </div>
                  )}
                </div>

                {/* WhatsApp Confirmation Trigger */}
                <div className="w-full space-y-2.5 pt-2">
                  <div className="flex flex-col space-y-1 text-left">
                    <span className="text-[11px] font-bold text-gray-300 uppercase font-mono tracking-wider">
                      Langkah 2: Kirim Rincian & Bukti ke WA
                    </span>
                    <p className="text-[10px] text-gray-500 leading-normal">
                      Klik tombol di bawah untuk membuka WhatsApp Admin. Rincian pesanan sudah otomatis disalin, Anda tinggal mengirimkannya beserta bukti foto di atas!
                    </p>
                  </div>

                  <motion.button
                    onClick={handleConfirmWhatsApp}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-extrabold py-3 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer font-sans"
                  >
                    <svg viewBox="0 0 24 24" width={16} height={16} fill="currentColor" className="inline-block stroke-[0.5]">
                      <path d="M12.012 2c-5.506 0-9.989 4.478-9.99 9.984a9.96 9.96 0 001.333 4.982L2 22l5.233-1.371a9.994 9.994 0 004.78 1.22h.004c5.505 0 9.99-4.478 9.99-9.985C22.012 6.478 17.521 2 12.012 2zm3.669 13.19c-.218.613-1.258 1.185-1.745 1.238-.475.051-.95.074-2.18-.413-1.57-.62-2.574-2.194-2.653-2.298-.078-.103-.637-.847-.637-1.616 0-.768.404-1.147.548-1.298.143-.15.312-.188.416-.188.104 0 .208.001.299.005.103.004.244-.039.381.291.143.344.49 1.192.533 1.281.043.089.072.192.013.31-.058.12-.088.192-.175.293-.088.102-.185.228-.264.31-.088.093-.18.194-.078.368.102.173.454.747.973 1.21.668.593 1.23.777 1.404.864.174.088.275.074.377-.044.103-.118.441-.513.56-.688.117-.174.234-.147.395-.088.162.059 1.026.484 1.213.578.188.094.312.141.358.218.046.077.046.448-.172 1.061z"/>
                    </svg>
                    KONFIRMASI PEMBAYARAN VIA WA
                  </motion.button>

                  <div className="flex justify-center pt-1.5 border-t border-white/5">
                    <button
                      type="button"
                      onClick={handleSimulatePayment}
                      disabled={simulating}
                      className="text-[10px] text-gray-500 hover:text-cyan-400 transition-colors flex items-center gap-1.5 cursor-pointer bg-transparent border-none"
                    >
                      {simulating ? 'Memverifikasi...' : '⚡ Lewati & Simulasikan Bayar Lunas (Untuk Testing)'}
                    </button>
                  </div>
                </div>
              </>
            ) : (
              // Status Paid or Delivered UI on right panel
              <div className="p-4 flex flex-col items-center justify-center text-center space-y-4 py-8">
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: 'spring', duration: 0.5 }}
                  className="h-16 w-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shadow-lg shadow-emerald-500/10"
                >
                  <Gift size={32} className="animate-bounce" />
                </motion.div>
                <div className="space-y-1.5">
                  <span className="text-sm font-extrabold text-white">PESANAN SEDANG DIPROSES</span>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    {order.status === 'DELIVERED'
                      ? 'Transaksi Anda sukses 100%! DGL telah kami taruh di World Anda.'
                      : `Kurir kami sedang meluncur ke World "${order.worldName}" untuk mengantar ${order.quantity} DGL.`}
                  </p>
                </div>
                
                <div className="p-3.5 rounded-lg bg-emerald-950/20 border border-emerald-800/30 text-xs text-emerald-300 text-left space-y-2.5 w-full">
                  <div className="font-semibold flex items-center gap-1">
                    <Sparkles size={14} />
                    <span>Langkah Anda Selanjutnya:</span>
                  </div>
                  <ol className="list-decimal pl-4 text-[11px] text-gray-300 space-y-1.5 leading-normal">
                    <li>Masuk ke dalam game Dreamtopia PS Anda.</li>
                    <li>Kunjungi World <strong className="font-mono text-white underline">{order.worldName}</strong>.</li>
                    <li>Periksa <strong className="text-white">Donation Box / Display Box</strong> Anda.</li>
                    <li>DGL Anda akan ditaruh di sana oleh Admin / Bot pengirim!</li>
                  </ol>
                </div>

                <div className="w-full pt-3">
                  <button
                    onClick={onNewOrderClick}
                    className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-lg text-xs cursor-pointer border border-white/5 transition-colors"
                  >
                    BELI DGL LAGI
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

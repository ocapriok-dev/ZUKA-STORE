import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, Trash2, Eye, TrendingUp, ShoppingCart, DollarSign, 
  Database, X, ChevronDown, ChevronUp, Globe, RefreshCw, Upload, 
  Sparkles, Check, Image as ImageIcon, Link, Settings2, ShieldCheck, 
  AlertCircle, ChevronRight, Monitor, Play, FileText, Smartphone,
  Lock, Unlock, EyeOff
} from 'lucide-react';
import { Order } from '../types';
import { formatRupiah } from '../utils/payment';

interface AdminPanelProps {
  orders: Order[];
  onStatusChange: (orderId: string, status: Order['status']) => void;
  onDeleteOrder: (orderId: string) => void;
  pricePerDgl: number;
  onPriceChange: (price: number) => void;
  productImage: string;
  onProductImageChange: (url: string) => void;
  stockAmount: number;
  onStockChange: (stock: number) => void;
  qrisQrCode: string;
  onQrisQrChange: (url: string) => void;
  adminPassword?: string;
  onAdminPasswordChange?: (password: string) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  orders,
  onStatusChange,
  onDeleteOrder,
  pricePerDgl,
  onPriceChange,
  productImage,
  onProductImageChange,
  stockAmount,
  onStockChange,
  qrisQrCode,
  onQrisQrChange,
  adminPassword = 'admin',
  onAdminPasswordChange
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'orders' | 'customizer'>('orders');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Customizer form inputs state
  const [inputPrice, setInputPrice] = useState(pricePerDgl);
  const [inputStock, setInputStock] = useState(stockAmount);
  const [inputImageUrl, setInputImageUrl] = useState(productImage);
  const [inputQrisUrl, setInputQrisUrl] = useState(qrisQrCode);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Security states
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // New admin password change states
  const [newPassword, setNewPassword] = useState('');
  const [passwordSaveSuccess, setPasswordSaveSuccess] = useState(false);

  // Sync inputs with live props from Firestore
  React.useEffect(() => {
    setInputPrice(pricePerDgl);
  }, [pricePerDgl]);

  React.useEffect(() => {
    setInputStock(stockAmount);
  }, [stockAmount]);

  React.useEffect(() => {
    setInputImageUrl(productImage);
  }, [productImage]);

  React.useEffect(() => {
    setInputQrisUrl(qrisQrCode);
  }, [qrisQrCode]);

  // File upload refs
  const productFileRef = useRef<HTMLInputElement>(null);
  const qrisFileRef = useRef<HTMLInputElement>(null);

  const [isProductDragging, setIsProductDragging] = useState(false);
  const [isQrisDragging, setIsQrisDragging] = useState(false);

  // Preset Premium Locks for quick selection
  const presetLocks = [
    { name: 'Obsidian Lock', url: '/src/assets/images/diamond_gem_lock_1783066536389.jpg' },
    { name: 'Holographic Lock', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=400' },
    { name: 'Ethereal Lock', url: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&q=80&w=400' }
  ];

  // Statistics
  const totalOrders = orders.length;
  const totalRevenue = orders
    .filter((o) => o.status === 'PAID' || o.status === 'DELIVERED')
    .reduce((sum, o) => sum + o.totalPrice, 0);
  const totalDglSold = orders
    .filter((o) => o.status === 'PAID' || o.status === 'DELIVERED')
    .reduce((sum, o) => sum + o.quantity, 0);

  const pendingOrdersCount = orders.filter((o) => o.status === 'PENDING').length;

  const handleProductUpload = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setInputImageUrl(base64);
    };
    reader.readAsDataURL(file);
  };

  const handleQrisUpload = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setInputQrisUrl(base64);
    };
    reader.readAsDataURL(file);
  };

  const saveConfiguration = () => {
    onPriceChange(inputPrice);
    onStockChange(inputStock);
    onProductImageChange(inputImageUrl);
    onQrisQrChange(inputQrisUrl);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
    }, 3000);
  };

  const resetToDefaultConfig = () => {
    if (confirm('Reset semua gambar toko, QRIS, dan harga kembali ke awal?')) {
      setInputPrice(27000);
      setInputStock(524);
      setInputImageUrl('/src/assets/images/diamond_gem_lock_1783066536389.jpg');
      setInputQrisUrl('');
      onPriceChange(27000);
      onStockChange(524);
      onProductImageChange('/src/assets/images/diamond_gem_lock_1783066536389.jpg');
      onQrisQrChange('');
      setSaveSuccess(true);
      setTimeout(() => {
        setSaveSuccess(false);
      }, 3000);
    }
  };

  const handleSavePassword = () => {
    if (!newPassword.trim()) {
      alert('Sandi baru tidak boleh kosong!');
      return;
    }
    if (onAdminPasswordChange) {
      onAdminPasswordChange(newPassword.trim());
      setPasswordSaveSuccess(true);
      setNewPassword('');
      setTimeout(() => setPasswordSaveSuccess(false), 3000);
    }
  };

  return (
    <div className="w-full">
      {/* Drawer Toggle Header */}
      <button
        onClick={() => {
          if (isOpen) {
            setIsAuthenticated(false);
          }
          setIsOpen(!isOpen);
        }}
        className="w-full flex items-center justify-between p-4 bg-slate-900/65 hover:bg-slate-800/80 border border-white/10 rounded-xl text-gray-300 hover:text-white transition-all cursor-pointer font-sans text-sm font-semibold shadow-xl shadow-cyan-500/5 relative z-30"
      >
        <div className="flex items-center gap-2">
          <ShieldAlert size={16} className="text-cyan-400 animate-pulse" />
          <span className="font-sans font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-300 to-cyan-400">
            ZUKA Owner Console v2.0
          </span>
          {pendingOrdersCount > 0 && (
            <span className="bg-rose-500 text-slate-950 font-black px-2.5 py-0.5 text-[10px] rounded-full animate-bounce">
              {pendingOrdersCount} Pesanan Baru
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <span className="bg-white/5 px-2 py-0.5 rounded font-mono text-[10px] text-cyan-300">ADMIN</span>
          <span>{isOpen ? 'Sembunyikan' : 'Buka Admin Console'}</span>
          {isOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden mt-3"
          >
            <div className="p-5 rounded-2xl bg-slate-950/90 backdrop-blur-xl border border-cyan-500/35 space-y-6 shadow-2xl relative z-30">
              {!isAuthenticated ? (
                <div className="py-8 px-4 flex flex-col items-center max-w-sm mx-auto text-center space-y-5">
                  <div className="w-14 h-14 rounded-full bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.15)] animate-bounce" style={{ animationDuration: '3s' }}>
                    <Lock size={24} />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">
                      Owner Console Terkunci
                    </h3>
                    <p className="text-[10.5px] text-gray-400 mt-1.5 leading-relaxed">
                      Sandi dilindungi database terdistribusi Firebase Firestore. Masukkan kunci otentikasi Anda untuk mengakses panel operasi.
                    </p>
                  </div>

                  <form onSubmit={(e) => {
                    e.preventDefault();
                    const correctPassword = adminPassword || 'admin';
                    if (passwordInput === correctPassword) {
                      setIsAuthenticated(true);
                      setLoginError('');
                      setPasswordInput('');
                    } else {
                      setLoginError('Sandi salah! Silakan coba lagi.');
                    }
                  }} className="w-full space-y-3">
                    <div className="relative">
                      <input
                        type={showPassword ? "text" : "password"}
                        placeholder="Masukkan sandi..."
                        value={passwordInput}
                        onChange={(e) => {
                          setPasswordInput(e.target.value);
                          setLoginError('');
                        }}
                        className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-2.5 text-center text-xs font-mono text-white focus:outline-none focus:border-cyan-500 transition-colors tracking-widest placeholder:tracking-normal"
                        autoFocus
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors p-1 cursor-pointer"
                      >
                        {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                    </div>

                    {loginError && (
                      <div className="text-[10px] font-bold text-red-400 bg-red-950/20 border border-red-900/30 py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5">
                        <AlertCircle size={12} />
                        {loginError}
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black rounded-xl text-xs tracking-wider cursor-pointer transition-all flex items-center justify-center gap-1.5 shadow-lg shadow-cyan-500/10"
                    >
                      <Unlock size={13} /> MASUK KONSOL
                    </button>
                  </form>
                </div>
              ) : (
                <>
                  {/* Tab Selector Nav */}
                  <div className="flex border-b border-white/5 pb-2 justify-between items-center gap-2">
                    <div className="flex gap-2">
                      <button
                        onClick={() => setActiveTab('orders')}
                        className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                          activeTab === 'orders'
                            ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                            : 'text-gray-400 hover:text-white hover:bg-white/5'
                        }`}
                      >
                        <Database size={13} />
                        📊 Live Operations & Transaksi
                      </button>
                      <button
                        onClick={() => setActiveTab('customizer')}
                        className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer relative ${
                          activeTab === 'customizer'
                            ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                            : 'text-gray-400 hover:text-white hover:bg-white/5'
                        }`}
                      >
                        <Globe size={13} />
                        🌐 CDN Media Customizer
                        <span className="absolute -top-1 -right-1 flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
                        </span>
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsAuthenticated(false)}
                      className="px-3 py-1.5 bg-rose-950/20 hover:bg-rose-900/40 border border-rose-900/30 text-rose-400 hover:text-rose-300 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <Lock size={12} /> Kunci Panel
                    </button>
                  </div>

              {activeTab === 'orders' ? (
                <>
                  {/* Stats Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="p-4 rounded-xl bg-slate-900/50 border border-white/5 flex items-center gap-3">
                      <div className="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-lg">
                        <ShoppingCart size={18} />
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-mono text-gray-500 block">Total Pesanan</span>
                        <span className="text-lg font-black text-white">{totalOrders}</span>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-900/50 border border-white/5 flex items-center gap-3">
                      <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-lg">
                        <DollarSign size={18} />
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-mono text-gray-500 block">Total Omset</span>
                        <span className="text-lg font-black text-emerald-400">{formatRupiah(totalRevenue)}</span>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-900/50 border border-white/5 flex items-center gap-3">
                      <div className="p-2.5 bg-purple-500/10 text-purple-400 rounded-lg">
                        <TrendingUp size={18} />
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-mono text-gray-500 block">DGL Terjual</span>
                        <span className="text-lg font-black text-purple-400">{totalDglSold} DGL</span>
                      </div>
                    </div>
                  </div>

                  {/* Orders Table */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white uppercase font-mono tracking-wider flex items-center gap-1.5">
                        <Database size={14} className="text-cyan-400" />
                        Daftar Transaksi Masuk
                      </span>
                      <span className="text-[10px] font-mono text-gray-500">Data otomatis sinkron live</span>
                    </div>

                    {orders.length === 0 ? (
                      <div className="p-8 text-center text-gray-500 border border-white/5 rounded-xl text-xs bg-slate-900/20">
                        Belum ada pesanan masuk. Coba lakukan checkout terlebih dahulu!
                      </div>
                    ) : (
                      <div className="overflow-x-auto border border-white/5 rounded-xl bg-slate-900/10">
                        <table className="w-full text-left border-collapse text-xs">
                          <thead>
                            <tr className="bg-slate-900/50 text-gray-400 font-mono border-b border-white/5">
                              <th className="p-3">Order ID</th>
                              <th className="p-3">GrowID</th>
                              <th className="p-3">World</th>
                              <th className="p-3">Jumlah</th>
                              <th className="p-3">Total Harga</th>
                              <th className="p-3">Status</th>
                              <th className="p-3 text-right">Aksi</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5 font-sans">
                            {orders.map((o) => (
                              <tr key={o.id} className="hover:bg-slate-900/40 transition-colors">
                                <td className="p-3 font-mono text-cyan-400 font-bold">{o.id}</td>
                                <td className="p-3 font-mono font-bold text-white">{o.growId}</td>
                                <td className="p-3 font-mono text-gray-300">{o.worldName}</td>
                                <td className="p-3 font-mono font-medium">{o.quantity} DGL</td>
                                <td className="p-3 font-mono text-emerald-400 font-bold">{formatRupiah(o.totalPrice)}</td>
                                <td className="p-3">
                                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    o.status === 'DELIVERED'
                                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                      : o.status === 'PAID'
                                      ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                                      : o.status === 'CANCELLED'
                                      ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                      : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                  }`}>
                                    {o.status}
                                  </span>
                                </td>
                                <td className="p-3 text-right flex items-center justify-end gap-1.5">
                                  <button
                                    onClick={() => setSelectedOrder(o)}
                                    className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-gray-300 transition-colors cursor-pointer"
                                    title="Detail Pesanan"
                                  >
                                    <Eye size={13} />
                                  </button>
                                  <button
                                    onClick={() => onDeleteOrder(o.id)}
                                    className="p-1.5 rounded bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 transition-colors cursor-pointer border border-rose-900/20"
                                    title="Hapus"
                                  >
                                    <Trash2 size={13} />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                /* Subdomain Customizer Simulator section */
                <div className="space-y-4">
                  {/* Glassmorphic simulated browser frame */}
                  <div className="border border-white/10 rounded-2xl overflow-hidden bg-slate-900/30">
                    
                    {/* Simulated Browser Address Bar & Window Header */}
                    <div className="bg-slate-900/90 px-4 py-3 border-b border-white/5 flex items-center justify-between gap-3 select-none">
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="w-2.5 h-2.5 rounded-full bg-rose-500 block"></span>
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500 block"></span>
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 block"></span>
                      </div>

                      <div className="flex items-center gap-1 bg-black/40 border border-white/5 px-3 py-1 rounded-lg w-full max-w-lg text-[11px] font-mono text-gray-400">
                        <Globe size={11} className="text-cyan-400 shrink-0" />
                        <span className="text-emerald-400">https://</span>
                        <span className="text-white">cdn-media.zukastore.com</span>
                        <span className="text-gray-500">/customizer/settings</span>
                      </div>

                      <div className="flex items-center gap-1 shrink-0 text-gray-400">
                        <span className="text-[10px] font-mono bg-white/5 px-2 py-0.5 rounded text-cyan-400 font-bold">LIVE SYNC</span>
                      </div>
                    </div>

                    {/* Viewport content */}
                    <div className="p-6 bg-slate-950/60 backdrop-blur-sm space-y-6">
                      
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-white/5 pb-4 gap-3">
                        <div>
                          <h4 className="text-sm font-bold text-white flex items-center gap-1.5 font-sans">
                            <Settings2 size={15} className="text-cyan-400 animate-spin" style={{ animationDuration: '4s' }} />
                            Manajer Pengaturan & Foto Toko DGL
                          </h4>
                          <p className="text-[11px] text-gray-400 mt-1">Ubah harga, stok live, unggah foto produk, dan setel kode QRIS baru secara instan di domain media terpisah ini.</p>
                        </div>
                        <button
                          type="button"
                          onClick={resetToDefaultConfig}
                          className="px-3 py-1 bg-slate-900 border border-white/10 hover:border-red-500/30 text-gray-400 hover:text-red-400 rounded-lg text-[10px] font-mono transition-all cursor-pointer flex items-center gap-1 shrink-0"
                        >
                          <RefreshCw size={10} /> Reset Ke Default
                        </button>
                      </div>

                      {/* Config Form Layout Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        
                        {/* Column 1: Core Pricing, Stock & Qris */}
                        <div className="space-y-4">
                          <div className="space-y-1.5 text-left">
                            <label className="text-[10px] uppercase font-mono text-gray-400 font-bold block">Harga Jual per DGL (IDR)</label>
                            <div className="relative">
                              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-xs">Rp</span>
                              <input
                                type="number"
                                value={inputPrice}
                                onChange={(e) => setInputPrice(Number(e.target.value))}
                                className="w-full bg-slate-900 border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-cyan-500 transition-colors"
                              />
                            </div>
                          </div>

                          <div className="space-y-1.5 text-left">
                            <label className="text-[10px] uppercase font-mono text-gray-400 font-bold block">Stok Ready DGL</label>
                            <input
                              type="number"
                              value={inputStock}
                              onChange={(e) => setInputStock(Number(e.target.value))}
                              className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-none focus:border-cyan-500 transition-colors"
                            />
                          </div>

                          {/* QRIS Upload / Image Link */}
                          <div className="space-y-2 border-t border-white/5 pt-4 text-left">
                            <label className="text-[10px] uppercase font-mono text-gray-400 font-bold block">Bukti QRIS Toko (Custom QR Code)</label>
                            <p className="text-[9px] text-gray-500 leading-normal">
                              Unggah foto QRIS Anda sendiri dari HP agar pembeli langsung memindai QRIS milik Anda saat check-out.
                            </p>

                            {/* Drop & Upload Area for QRIS */}
                            <div
                              onDragOver={(e) => { e.preventDefault(); setIsQrisDragging(true); }}
                              onDragLeave={() => setIsQrisDragging(false)}
                              onDrop={(e) => {
                                e.preventDefault();
                                setIsQrisDragging(false);
                                const file = e.dataTransfer.files?.[0];
                                if (file && file.type.startsWith('image/')) {
                                  handleQrisUpload(file);
                                }
                              }}
                              onClick={() => qrisFileRef.current?.click()}
                              className={`border-2 border-dashed rounded-xl p-3 flex flex-col items-center justify-center cursor-pointer transition-all ${
                                isQrisDragging ? 'border-cyan-400 bg-cyan-950/20' : 'border-white/10 hover:border-cyan-500/30'
                              }`}
                            >
                              <input
                                type="file"
                                ref={qrisFileRef}
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) handleQrisUpload(file);
                                }}
                                accept="image/*"
                                className="hidden"
                              />
                              <Upload size={18} className="text-cyan-400 mb-1" />
                              <span className="text-[10px] font-bold text-gray-300">Pilih / Taruh Foto QRIS</span>
                              <span className="text-[8px] text-gray-500 mt-0.5">Mendukung format PNG / JPG</span>
                            </div>

                            {/* QRIS Preview & Input string */}
                            {inputQrisUrl && (
                              <div className="flex items-center gap-2 p-2 bg-slate-900 rounded-lg border border-white/5">
                                <img src={inputQrisUrl} alt="QRIS preview" className="w-10 h-10 object-contain rounded" />
                                <div className="overflow-hidden w-full text-ellipsis whitespace-nowrap text-[9px] text-gray-400">
                                  <span>Tersimpan sebagai Gambar Custom (Base64)</span>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => setInputQrisUrl('')}
                                  className="text-red-400 hover:text-red-300 text-[10px] shrink-0 font-mono"
                                >
                                  Hapus
                                </button>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Column 2: Product Lock Image customizer */}
                        <div className="space-y-4 border-t md:border-t-0 md:border-l border-white/5 md:pl-6 text-left">
                          <label className="text-[10px] uppercase font-mono text-gray-400 font-bold block">Desain/Foto Produk Diamond Gem Lock</label>
                          <p className="text-[9px] text-gray-500 leading-normal">
                            Ingin mengubah visual DGL di beranda utama? Pilih salah satu desain preset keren atau unggah gambar lock custom Anda sendiri!
                          </p>

                          {/* Predefined selection */}
                          <div className="grid grid-cols-3 gap-2">
                            {presetLocks.map((lock, idx) => (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => setInputImageUrl(lock.url)}
                                className={`p-1 bg-slate-900 hover:bg-slate-800 rounded-lg border flex flex-col items-center gap-1 transition-all ${
                                  inputImageUrl === lock.url ? 'border-cyan-400 ring-1 ring-cyan-400/40 scale-105' : 'border-white/5'
                                }`}
                              >
                                <img src={lock.url} alt={lock.name} className="w-12 h-12 object-cover rounded-md" referrerPolicy="no-referrer" />
                                <span className="text-[8px] text-gray-400 block font-sans text-center truncate w-full">{lock.name}</span>
                              </button>
                            ))}
                          </div>

                          {/* File Uploader for Product Lock Image */}
                          <div className="space-y-2 pt-2">
                            <span className="text-[9px] text-gray-400 block font-mono uppercase">Atau Unggah Gambar Custom:</span>
                            <div
                              onDragOver={(e) => { e.preventDefault(); setIsProductDragging(true); }}
                              onDragLeave={() => setIsProductDragging(false)}
                              onDrop={(e) => {
                                e.preventDefault();
                                setIsProductDragging(false);
                                const file = e.dataTransfer.files?.[0];
                                if (file && file.type.startsWith('image/')) {
                                  handleProductUpload(file);
                                }
                              }}
                              onClick={() => productFileRef.current?.click()}
                              className={`border-2 border-dashed rounded-xl p-3.5 flex flex-col items-center justify-center cursor-pointer transition-all ${
                                isProductDragging ? 'border-cyan-400 bg-cyan-950/20' : 'border-white/10 hover:border-cyan-500/30'
                              }`}
                            >
                              <input
                                type="file"
                                ref={productFileRef}
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) handleProductUpload(file);
                                }}
                                accept="image/*"
                                className="hidden"
                              />
                              <ImageIcon size={18} className="text-cyan-400 mb-1" />
                              <span className="text-[10px] font-bold text-gray-300">Pilih Foto DGL Anda</span>
                              <span className="text-[8px] text-gray-500 mt-0.5">Seret & lepas foto apa saja di sini</span>
                            </div>
                          </div>

                          {/* Image preview of DGL */}
                          <div className="p-3 bg-slate-900/60 rounded-xl border border-white/5 flex items-center gap-3">
                            <img src={inputImageUrl} alt="DGL preview" className="w-14 h-14 object-cover rounded-lg border border-white/10" referrerPolicy="no-referrer" />
                            <div>
                              <span className="text-[9px] text-gray-400 block font-mono">PREVIEW AKTIF:</span>
                              <span className="text-xs font-bold text-white block">Diamond Gem Lock</span>
                              <span className="text-[8px] text-cyan-400 font-mono block truncate max-w-[180px]">{inputImageUrl.startsWith('data:') ? 'Custom Upload (Base64)' : inputImageUrl}</span>
                            </div>
                          </div>
                        </div>

                      </div>

                      {/* Section: Change Password / Otentikasi */}
                      <div className="border-t border-white/5 pt-5 space-y-3 text-left">
                        <div>
                          <h5 className="text-xs font-bold text-white flex items-center gap-1.5 font-sans">
                            <Lock size={13} className="text-cyan-400" />
                            Ubah Kunci Otentikasi Admin (Sandi Firestore)
                          </h5>
                          <p className="text-[10px] text-gray-400 mt-0.5">
                            Ganti kunci sandi Anda di sini. Kunci sandi ini akan langsung disinkronkan ke cloud, mengamankan control panel dari orang lain.
                          </p>
                        </div>

                        <div className="flex flex-col sm:flex-row gap-3 items-end">
                          <div className="flex-1 w-full space-y-1.5">
                            <label className="text-[9px] uppercase font-mono text-gray-400 block">Kunci Sandi Baru</label>
                            <input
                              type="text"
                              value={newPassword}
                              onChange={(e) => setNewPassword(e.target.value)}
                              placeholder="Masukkan kunci sandi baru..."
                              className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-none focus:border-cyan-500 transition-colors"
                            />
                          </div>
                          
                          <button
                            type="button"
                            onClick={handleSavePassword}
                            className="w-full sm:w-auto px-5 py-2 bg-slate-900 hover:bg-slate-800 border border-white/10 hover:border-cyan-500/30 text-xs text-cyan-400 hover:text-cyan-300 rounded-xl font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 h-[34px] shrink-0"
                          >
                            <Check size={12} /> Simpan Sandi Baru
                          </button>
                        </div>

                        <AnimatePresence>
                          {passwordSaveSuccess && (
                            <motion.p
                              initial={{ opacity: 0, y: -5 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0 }}
                              className="text-[10px] text-emerald-400 font-bold bg-emerald-950/20 border border-emerald-900/30 py-1 px-3 rounded-lg inline-block"
                            >
                              Sandi sukses diperbarui di cloud Firestore!
                            </motion.p>
                          )}
                        </AnimatePresence>
                      </div>

                      {/* Action buttons & Alerts */}
                      <div className="border-t border-white/5 pt-4 flex flex-col sm:flex-row justify-between items-center gap-3">
                        <div className="w-full sm:w-auto text-left">
                          <AnimatePresence>
                            {saveSuccess && (
                              <motion.div
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0 }}
                                className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold bg-emerald-950/40 border border-emerald-900/30 px-3.5 py-1.5 rounded-lg"
                              >
                                <Check size={14} className="stroke-[3]" />
                                Konfigurasi sukses tersinkron ke beranda!
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>

                        <button
                          type="button"
                          onClick={saveConfiguration}
                          className="w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 cursor-pointer transition-all"
                        >
                          <Check size={14} className="stroke-[3]" /> SINKRONKAN PERUBAHAN TOKO
                        </button>
                      </div>

                    </div>
                  </div>
                </div>
              )}
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Order Detail Modal */}
      <AnimatePresence>
        {selectedOrder && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-lg bg-slate-900 border border-cyan-500/40 rounded-2xl p-6 shadow-2xl relative text-white"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedOrder(null)}
                className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-gray-400 hover:text-white transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>

              <div className="space-y-5">
                <div className="border-b border-white/5 pb-3">
                  <h3 className="text-base font-bold font-mono text-cyan-400">Detail Pesanan: {selectedOrder.id}</h3>
                  <span className="text-[10px] text-gray-400 font-sans">{new Date(selectedOrder.createdAt).toLocaleString('id-ID')}</span>
                </div>

                {/* Details layout */}
                <div className="grid grid-cols-2 gap-4 text-xs font-sans">
                  <div>
                    <span className="text-gray-400 block mb-0.5">GrowID:</span>
                    <strong className="text-sm text-white font-mono">{selectedOrder.growId}</strong>
                  </div>
                  <div>
                    <span className="text-gray-400 block mb-0.5">World Name:</span>
                    <strong className="text-sm text-white font-mono">{selectedOrder.worldName}</strong>
                  </div>
                  <div>
                    <span className="text-gray-400 block mb-0.5">Jumlah DGL:</span>
                    <span className="font-mono text-sm font-bold text-cyan-400 bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/30">{selectedOrder.quantity} DGL</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block mb-0.5">Metode Pengiriman:</span>
                    <strong className="text-white">{selectedOrder.deliveryMethod === 'donation_box' ? 'Donation Box' : 'Trade In-Game'}</strong>
                  </div>
                  <div>
                    <span className="text-gray-400 block mb-0.5">Kontak Pembeli:</span>
                    <strong className="text-gray-200">{selectedOrder.contact}</strong>
                  </div>
                  <div>
                    <span className="text-gray-400 block mb-0.5">Metode Bayar:</span>
                    <strong className="text-white uppercase">{selectedOrder.paymentMethod}</strong>
                  </div>
                </div>

                {selectedOrder.notes && (
                  <div className="p-3 rounded bg-slate-950 text-xs text-gray-400">
                    <span className="font-bold text-gray-300 block mb-0.5">Catatan:</span>
                    "{selectedOrder.notes}"
                  </div>
                )}

                <div className="p-4 rounded-xl bg-slate-950/60 border border-white/5 flex justify-between items-center text-xs">
                  <div>
                    <span className="text-gray-400 block mb-0.5">Status Saat Ini:</span>
                    <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                      selectedOrder.status === 'DELIVERED'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : selectedOrder.status === 'PAID'
                        ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                        : selectedOrder.status === 'CANCELLED'
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    }`}>
                      {selectedOrder.status}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400 block mb-0.5 text-right">Total Transaksi:</span>
                    <span className="text-base font-black text-emerald-400 font-mono">{formatRupiah(selectedOrder.totalPrice)}</span>
                  </div>
                </div>

                {/* Status Change Control Buttons */}
                <div className="space-y-2 border-t border-white/5 pt-4">
                  <span className="text-xs font-bold text-white block">Ubah Status Pesanan</span>
                  <div className="grid grid-cols-4 gap-1.5">
                    <button
                      onClick={() => {
                        onStatusChange(selectedOrder.id, 'PENDING');
                        setSelectedOrder({ ...selectedOrder, status: 'PENDING' });
                      }}
                      className={`py-2 text-[10px] font-bold rounded transition-colors cursor-pointer border ${
                        selectedOrder.status === 'PENDING' ? 'bg-amber-500 text-slate-950 border-amber-400' : 'bg-slate-800 text-gray-300 hover:bg-slate-700 border-transparent'
                      }`}
                    >
                      PENDING
                    </button>
                    <button
                      onClick={() => {
                        onStatusChange(selectedOrder.id, 'PAID');
                        setSelectedOrder({ ...selectedOrder, status: 'PAID' });
                      }}
                      className={`py-2 text-[10px] font-bold rounded transition-colors cursor-pointer border ${
                        selectedOrder.status === 'PAID' ? 'bg-blue-500 text-white border-blue-400' : 'bg-slate-800 text-gray-300 hover:bg-slate-700 border-transparent'
                      }`}
                    >
                      PAID
                    </button>
                    <button
                      onClick={() => {
                        onStatusChange(selectedOrder.id, 'DELIVERED');
                        setSelectedOrder({ ...selectedOrder, status: 'DELIVERED' });
                      }}
                      className={`py-2 text-[10px] font-bold rounded transition-colors cursor-pointer border ${
                        selectedOrder.status === 'DELIVERED' ? 'bg-emerald-500 text-slate-950 border-emerald-400' : 'bg-slate-800 text-gray-300 hover:bg-slate-700 border-transparent'
                      }`}
                    >
                      DELIVERED
                    </button>
                    <button
                      onClick={() => {
                        onStatusChange(selectedOrder.id, 'CANCELLED');
                        setSelectedOrder({ ...selectedOrder, status: 'CANCELLED' });
                      }}
                      className={`py-2 text-[10px] font-bold rounded transition-colors cursor-pointer border ${
                        selectedOrder.status === 'CANCELLED' ? 'bg-rose-500 text-white border-rose-400' : 'bg-slate-800 text-gray-300 hover:bg-slate-700 border-transparent'
                      }`}
                    >
                      CANCEL
                    </button>
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    onClick={() => setSelectedOrder(null)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                  >
                    TUTUP DETAIL
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

import React from 'react';
import { motion } from 'motion/react';
import { Minus, Plus, ShoppingBag, ShieldCheck, Zap, Info } from 'lucide-react';
import { formatRupiah, PRICE_PER_DGL } from '../utils/payment';

// Default generated DGL image
const DEFAULT_DGL_IMAGE = '/src/assets/images/diamond_gem_lock_1783066536389.jpg';

interface DGLProductCardProps {
  quantity: number;
  onQuantityChange: (qty: number) => void;
  onCheckoutClick: () => void;
  pricePerDgl?: number;
  productImage?: string;
  stockAmount?: number;
}

export const DGLProductCard: React.FC<DGLProductCardProps> = ({
  quantity,
  onQuantityChange,
  onCheckoutClick,
  pricePerDgl = PRICE_PER_DGL,
  productImage = DEFAULT_DGL_IMAGE,
  stockAmount = 524
}) => {
  const increment = () => onQuantityChange(quantity + 1);
  const decrement = () => {
    if (quantity > 1) {
      onQuantityChange(quantity - 1);
    }
  };

  const handlePresetClick = (presetQty: number) => {
    onQuantityChange(presetQty);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value, 10);
    if (!isNaN(val) && val > 0) {
      onQuantityChange(val);
    } else if (e.target.value === '') {
      onQuantityChange(1); // fallback
    }
  };

  const presets = [1, 5, 10, 25, 50, 100];
  const totalPrice = quantity * pricePerDgl;

  return (
    <div className="flex flex-col md:flex-row items-center gap-8 py-4">
      {/* Product Image Section */}
      <div className="w-full md:w-1/2 flex flex-col items-center">
        <motion.div
          className="relative group p-1 rounded-2xl overflow-hidden bg-gradient-to-tr from-cyan-500 via-blue-600 to-purple-600 shadow-2xl shadow-cyan-500/10"
          whileHover={{ scale: 1.03 }}
          transition={{ type: 'spring', stiffness: 200, damping: 15 }}
        >
          {/* Pulsing light aura */}
          <div className="absolute inset-0 bg-cyan-500/20 blur-xl rounded-full scale-75 animate-pulse" />

          <img
            src={productImage}
            alt="Diamond Gem Lock"
            className="w-64 h-64 md:w-72 md:h-72 object-cover rounded-xl border border-white/10 relative z-10 transition-transform group-hover:rotate-2 duration-300"
            referrerPolicy="no-referrer"
          />

          <span className="absolute bottom-3 right-3 z-15 bg-slate-950/80 backdrop-blur-md text-[10px] text-cyan-400 font-mono font-bold px-2 py-1 rounded border border-cyan-500/30">
            DREAMTOPIA ITEM
          </span>
        </motion.div>

        {/* Feature Badges */}
        <div className="flex gap-4 mt-6 justify-center w-full">
          <div className="flex items-center gap-1.5 text-xs text-cyan-400 bg-cyan-950/30 border border-cyan-900/30 px-3 py-1.5 rounded-full">
            <Zap size={14} className="animate-bounce" />
            <span>Proses Instant 5 Menit</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-purple-400 bg-purple-950/30 border border-purple-900/30 px-3 py-1.5 rounded-full">
            <ShieldCheck size={14} />
            <span>Garansi 100% Aman</span>
          </div>
        </div>
      </div>

      {/* Control and Checkout Section */}
      <div className="w-full md:w-1/2 flex flex-col space-y-6">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-[11px] font-mono uppercase bg-blue-500/20 text-blue-400 px-2.5 py-0.5 rounded font-bold border border-blue-500/30">
              BEST SELLER
            </span>
            <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              {stockAmount > 0 ? `Stok: ${stockAmount} DGL Ready` : 'Stok Menipis (Ready)'}
            </span>
          </div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            Diamond Gem Lock (DGL)
          </h2>
          <p className="text-gray-400 text-sm mt-2 leading-relaxed">
            Mata uang premium terbaik untuk server <strong>Dreamtopia PS</strong>. Dapatkan dengan harga termurah, proses pengiriman super cepat, dan garansi keamanan transaksi penuh dari ZUKA Store.
          </p>
        </div>

        {/* Pricing tag */}
        <div className="p-4 rounded-xl bg-slate-900/40 border border-white/5 flex justify-between items-center">
          <div>
            <span className="text-xs text-gray-400 uppercase font-mono tracking-wider block">Harga per DGL</span>
            <span className="text-2xl font-black text-cyan-400">
              {formatRupiah(pricePerDgl)}
            </span>
          </div>
          <div className="text-right">
            <span className="text-xs text-gray-500 line-through block">
              {formatRupiah(Math.round(pricePerDgl * 1.3))}
            </span>
            <span className="text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              Hemat 23%
            </span>
          </div>
        </div>

        {/* Quantity Selector */}
        <div className="space-y-3">
          <label className="text-xs font-semibold text-gray-300 uppercase tracking-wider block">
            Jumlah Pembelian (DGL)
          </label>
          <div className="flex items-center gap-3">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={decrement}
              disabled={quantity <= 1}
              className="w-12 h-12 rounded-lg bg-slate-800/80 text-white flex items-center justify-center border border-white/10 hover:bg-slate-700/80 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Minus size={18} />
            </motion.button>

            <input
              type="number"
              value={quantity}
              onChange={handleInputChange}
              min="1"
              className="w-24 h-12 bg-slate-950/70 text-center font-mono text-xl font-bold text-white border border-cyan-500/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />

            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={increment}
              className="w-12 h-12 rounded-lg bg-slate-800/80 text-white flex items-center justify-center border border-white/10 hover:bg-slate-700/80 transition-colors"
            >
              <Plus size={18} />
            </motion.button>
          </div>

          {/* Quick Select Buttons */}
          <div className="flex flex-wrap gap-2 pt-1">
            {presets.map((preset) => (
              <button
                key={preset}
                onClick={() => handlePresetClick(preset)}
                className={`text-xs font-mono px-3 py-1.5 rounded-md transition-all duration-200 ${
                  quantity === preset
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-lg shadow-cyan-500/20 scale-105 border border-cyan-400'
                    : 'bg-slate-950/40 border border-white/5 text-gray-400 hover:text-white hover:border-cyan-500/30'
                }`}
              >
                +{preset} DGL
              </button>
            ))}
          </div>
        </div>

        {/* Live Total Bill */}
        <div className="border-t border-white/5 pt-4 space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-300">Total Harga:</span>
            <motion.span
              key={totalPrice}
              initial={{ scale: 0.95, opacity: 0.8 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 drop-shadow-[0_0_12px_rgba(6,182,212,0.3)]"
            >
              {formatRupiah(totalPrice)}
            </motion.span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-gray-500">
            <Info size={12} />
            <span>Tidak ada biaya admin tambahan untuk pembayaran E-wallet/QRIS</span>
          </div>
        </div>

        {/* Checkout Button */}
        <motion.button
          onClick={onCheckoutClick}
          whileHover={{ scale: 1.02, boxShadow: '0 0 20px rgba(6, 182, 212, 0.4)' }}
          whileTap={{ scale: 0.98 }}
          className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-extrabold text-base py-4 rounded-xl flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/10 cursor-pointer transition-all duration-300 font-sans"
        >
          <ShoppingBag size={20} className="stroke-[2.5]" />
          BELI SEKARANG (CHECKOUT)
        </motion.button>
      </div>
    </div>
  );
};

import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Zap } from 'lucide-react';

export const ZukaLogo: React.FC = () => {
  // Staggered reveal for the entire logo container
  const logoContainerVariants = {
    initial: {},
    animate: {
      transition: {
        staggerChildren: 0.1,
      }
    }
  };

  const letterVariants = {
    initial: { 
      opacity: 0, 
      y: 15, 
      scale: 0.6,
      filter: "blur(4px) drop-shadow(0 0 0px rgba(6,182,212,0))"
    },
    animate: (idx: number) => ({ 
      opacity: 1, 
      y: [0, -6, 0], 
      scale: [1, 1.05, 1],
      filter: [
        "blur(0px) drop-shadow(0 0 6px rgba(6,182,212,0.3))",
        "blur(0px) drop-shadow(0 0 15px rgba(6,182,212,0.7))",
        "blur(0px) drop-shadow(0 0 6px rgba(6,182,212,0.3))"
      ],
      transition: {
        y: {
          duration: 2.5,
          repeat: Infinity,
          ease: "easeInOut",
          delay: idx * 0.15
        },
        scale: {
          duration: 2.5,
          repeat: Infinity,
          ease: "easeInOut",
          delay: idx * 0.15
        },
        filter: {
          duration: 2.5,
          repeat: Infinity,
          ease: "easeInOut",
          delay: idx * 0.15
        },
        opacity: {
          duration: 0.4,
          delay: idx * 0.15
        }
      }
    }),
    hover: {
      scale: 1.25,
      y: -8,
      rotate: [0, -3, 3, 0],
      filter: "brightness(1.4) drop-shadow(0 0 18px rgba(0,255,255,0.95)) drop-shadow(0 0 30px rgba(168,85,247,0.75))",
      transition: { duration: 0.25 }
    }
  };

  const sparklesVariants = {
    initial: { opacity: 0, scale: 0, rotate: -120 },
    animate: { 
      opacity: 1, 
      scale: [1, 1.15, 1], 
      rotate: [0, 360],
      y: [0, -3, 0],
      transition: {
        opacity: { duration: 0.4 },
        rotate: { duration: 15, repeat: Infinity, ease: "linear" },
        scale: { duration: 3, repeat: Infinity, ease: "easeInOut" },
        y: { duration: 2, repeat: Infinity, ease: "easeInOut" }
      }
    }
  };

  // Staggered sequence for tagline components (appears word-by-word / part-by-part)
  const taglineContainerVariants = {
    initial: {},
    animate: {
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.7 // Starts right after "ZUKA" finishes
      }
    }
  };

  const badgeVariants = {
    initial: { opacity: 0, scale: 0.7, x: -15, filter: "blur(2px)" },
    animate: { 
      opacity: 1, 
      scale: 1, 
      x: 0,
      filter: "blur(0px)",
      transition: {
        type: "spring",
        stiffness: 180,
        damping: 14
      }
    }
  };

  const statusDotVariants = {
    initial: { opacity: 0, scale: 0 },
    animate: { 
      opacity: 1, 
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 250,
        damping: 12
      }
    }
  };

  const statusTextVariants = {
    initial: { opacity: 0, x: -8 },
    animate: { 
      opacity: 1, 
      x: 0,
      transition: {
        type: "spring",
        stiffness: 200,
        damping: 15
      }
    }
  };

  return (
    <div className="flex flex-col items-start select-none cursor-pointer group">
      {/* Top Main Brand Line */}
      <motion.div
        variants={logoContainerVariants}
        initial="initial"
        animate="animate"
        className="flex items-center gap-2.5 relative"
      >
        {/* Glowing background radial blur */}
        <div className="absolute -inset-3 bg-gradient-to-r from-cyan-500/10 via-purple-500/5 to-blue-500/10 blur-xl opacity-70 rounded-full group-hover:scale-125 transition-transform duration-700 pointer-events-none" />

        {/* Floating animated sparkles icon with pulse aura */}
        <motion.div
          variants={sparklesVariants}
          initial="initial"
          animate="animate"
          className="text-transparent bg-clip-text bg-gradient-to-tr from-cyan-400 to-blue-400 drop-shadow-[0_0_12px_rgba(6,182,212,0.9)] relative z-10"
        >
          <Sparkles size={26} className="fill-cyan-400/30 text-cyan-400 stroke-[1.8]" />
        </motion.div>

        {/* High-end animated text with sliding holographic sheen */}
        <motion.div className="relative overflow-hidden py-1 px-2.5 rounded-lg bg-white/[0.02] border border-white/[0.05] backdrop-blur-sm shadow-[inset_0_1px_1px_rgba(255,255,255,0.05)]">
          {/* Shimmer line sliding across the logo letters */}
          <motion.div
            animate={{ x: ['-100%', '300%'] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", repeatDelay: 1.5 }}
            className="absolute top-0 bottom-0 w-12 bg-gradient-to-r from-transparent via-cyan-400/20 to-transparent skew-x-25 pointer-events-none z-10"
          />

          <span className="flex text-3.5xl font-black tracking-widest font-sans text-white relative z-10">
            {["Z", "U", "K", "A"].map((letter, idx) => (
              <motion.span
                key={idx}
                initial={{ opacity: 0, y: 15, filter: "blur(4px)" }}
                animate={{ 
                  opacity: 1, 
                  y: [0, -8, 0],
                  filter: "blur(0px)" 
                }}
                transition={{
                  y: {
                    duration: 2.2,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: idx * 0.18
                  },
                  opacity: { duration: 0.5, delay: idx * 0.15 },
                  filter: { duration: 0.5, delay: idx * 0.15 }
                }}
                whileHover={{
                  scale: 1.25,
                  y: -8,
                  transition: { duration: 0.2 }
                }}
                className="inline-block bg-clip-text text-transparent bg-gradient-to-b from-white via-cyan-100 to-cyan-300 select-none"
              >
                {letter}
              </motion.span>
            ))}
          </span>
        </motion.div>
      </motion.div>
      
      {/* Dynamic Staggered Tagline: Appears "Word-By-Word" (Badge, Dot, then Text) */}
      <motion.div 
        variants={taglineContainerVariants}
        initial="initial"
        animate="animate"
        className="flex items-center gap-1.5 mt-1.5 ml-1 relative z-10"
      >
        {/* Word 1: Store Type Badge */}
        <motion.span 
          variants={badgeVariants}
          className="text-[9px] uppercase font-mono tracking-[0.35em] text-cyan-300 font-black bg-cyan-950/50 hover:bg-cyan-900/60 transition-colors px-2 py-0.5 rounded-md border border-cyan-500/30 shadow-[0_0_8px_rgba(6,182,212,0.15)] flex items-center gap-1"
        >
          <Zap size={10} className="text-amber-400 animate-pulse fill-amber-400/20" />
          DGL STORE
        </motion.span>

        {/* Word 2: Pulse Indicator */}
        <motion.span 
          variants={statusDotVariants}
          className="flex h-1.5 w-1.5 relative"
        >
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
        </motion.span>

        {/* Word 3: Online status text */}
        <motion.span 
          variants={statusTextVariants}
          className="text-[8px] font-mono tracking-wider text-emerald-400 font-bold uppercase"
        >
          ONLINE
        </motion.span>
      </motion.div>
    </div>
  );
};

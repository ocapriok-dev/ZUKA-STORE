import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, MessageSquarePlus, User, Calendar, ShieldCheck, AlertCircle } from 'lucide-react';
import { Testimonial } from '../types';

interface TestimonialsProps {
  testimonials: Testimonial[];
  onAddTestimonial: (testi: Omit<Testimonial, 'id' | 'date'>) => void;
}

export const Testimonials: React.FC<TestimonialsProps> = ({
  testimonials,
  onAddTestimonial
}) => {
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [growId, setGrowId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !growId.trim() || !comment.trim()) {
      setError('Harap lengkapi semua bidang!');
      return;
    }
    
    onAddTestimonial({
      name: name.trim(),
      growId: growId.trim(),
      rating,
      comment: comment.trim(),
      quantity
    });

    // Reset Form
    setName('');
    setGrowId('');
    setQuantity(1);
    setRating(5);
    setComment('');
    setError('');
    setShowForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center border-b border-white/5 pb-4">
        <div>
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <ShieldCheck size={18} className="text-cyan-400" />
            <span>Ulasan & Testimoni Pelanggan</span>
          </h3>
          <p className="text-xs text-gray-400 mt-0.5">Ulasan asli dari pembeli DGL ZUKA Store.</p>
        </div>

        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 hover:text-cyan-300 font-bold text-xs transition-all border border-cyan-500/20 cursor-pointer"
        >
          <MessageSquarePlus size={14} />
          <span>{showForm ? 'Tutup Formulir' : 'Kirim Ulasan'}</span>
        </button>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-5 rounded-xl bg-slate-900/60 border border-cyan-500/20 space-y-4"
          >
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <span className="font-extrabold text-white text-xs block uppercase font-mono tracking-wider text-cyan-400">Tulis Testimoni Anda</span>
              
              {error && (
                <div className="p-3 bg-rose-950/20 border border-rose-800/30 text-rose-300 rounded flex items-center gap-2">
                  <AlertCircle size={14} />
                  <span>{error}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-gray-400 font-medium">Nama Anda</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Contoh: Budi Santoso"
                    className="w-full bg-slate-950 px-3 py-2.5 rounded border border-white/10 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-gray-400 font-medium">GrowID Anda</label>
                  <input
                    type="text"
                    value={growId}
                    onChange={(e) => setGrowId(e.target.value)}
                    placeholder="Contoh: BudiGT"
                    className="w-full bg-slate-950 px-3 py-2.5 rounded border border-white/10 text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-gray-400 font-medium">DGL yang Dibeli</label>
                  <input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    min="1"
                    className="w-full bg-slate-950 px-3 py-2.5 rounded border border-white/10 text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-gray-400 font-medium block">Rating Bintang</label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        className="text-amber-400 hover:scale-110 transition-transform cursor-pointer"
                      >
                        <Star
                          size={20}
                          className={star <= rating ? 'fill-amber-400 text-amber-400' : 'text-gray-600'}
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-gray-400 font-medium">Ulasan / Kritik & Saran</label>
                <textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows={2}
                  placeholder="Ceritakan pengalaman Anda membeli DGL di ZUKA Store..."
                  className="w-full bg-slate-950 px-3 py-2.5 rounded border border-white/10 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500 resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold cursor-pointer shadow-lg shadow-cyan-500/15"
                >
                  Kirim Ulasan Saya
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Grid of Testimonials */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {testimonials.map((t, idx) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="p-4 rounded-xl bg-slate-900/40 border border-white/5 space-y-3 relative overflow-hidden"
          >
            {/* Glow accent */}
            <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/5 blur-xl rounded-full" />

            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center text-cyan-400">
                  <User size={14} />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">{t.name}</span>
                  <span className="text-[10px] text-gray-500 font-mono">GrowID: {t.growId}</span>
                </div>
              </div>

              {/* Stars rating */}
              <div className="flex gap-0.5 text-amber-400">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} size={11} className="fill-amber-400 text-amber-400" />
                ))}
              </div>
            </div>

            <p className="text-xs text-gray-300 leading-relaxed italic font-sans">
              "{t.comment}"
            </p>

            <div className="flex justify-between items-center text-[9px] font-mono border-t border-white/5 pt-2.5 text-gray-500">
              <span className="flex items-center gap-1">
                <Calendar size={10} />
                {t.date}
              </span>
              <span className="text-cyan-400 bg-cyan-500/5 px-2 py-0.5 rounded border border-cyan-500/10 font-bold">
                Membeli {t.quantity} DGL
              </span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

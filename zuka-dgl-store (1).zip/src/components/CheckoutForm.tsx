import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Send, CheckCircle2, AlertTriangle, MessageSquare, Compass, Wallet, Truck } from 'lucide-react';
import { PaymentMethodId } from '../types';
import { PAYMENT_METHODS, formatRupiah, PRICE_PER_DGL } from '../utils/payment';

interface CheckoutFormProps {
  quantity: number;
  onBackClick: () => void;
  onSubmit: (formData: {
    growId: string;
    worldName: string;
    deliveryMethod: 'donation_box' | 'trade';
    paymentMethod: PaymentMethodId;
    contact: string;
    notes?: string;
  }) => void;
  pricePerDgl?: number;
}

export const CheckoutForm: React.FC<CheckoutFormProps> = ({
  quantity,
  onBackClick,
  onSubmit,
  pricePerDgl = PRICE_PER_DGL
}) => {
  const [growId, setGrowId] = useState('');
  const [worldName, setWorldName] = useState('');
  const [deliveryMethod, setDeliveryMethod] = useState<'donation_box' | 'trade'>('donation_box');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethodId>('qris');
  const [contact, setContact] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!growId.trim()) newErrors.growId = 'GrowID wajib diisi untuk pengiriman DGL';
    if (!worldName.trim()) newErrors.worldName = 'World Name wajib diisi';
    if (!contact.trim()) newErrors.contact = 'Kontak (WhatsApp / Discord) wajib diisi';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit({
        growId: growId.trim(),
        worldName: worldName.trim(),
        deliveryMethod,
        paymentMethod,
        contact: contact.trim(),
        notes: notes.trim()
      });
    }
  };

  const totalPrice = quantity * pricePerDgl;

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Header back button & title */}
      <div className="flex items-center gap-4 border-b border-white/5 pb-4">
        <motion.button
          type="button"
          onClick={onBackClick}
          whileHover={{ scale: 1.05 }}
          className="p-2 rounded-lg bg-slate-900/60 hover:bg-slate-800 text-gray-400 hover:text-white transition-colors cursor-pointer border border-white/5"
        >
          <ArrowLeft size={16} />
        </motion.button>
        <div>
          <h2 className="text-xl font-bold text-white">Formulir Checkout Pesanan</h2>
          <p className="text-xs text-gray-400">Lengkapi data karakter Growtopia & metode pembayaran Anda.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Delivery Details */}
        <div className="lg:col-span-7 space-y-5">
          <div className="flex items-center gap-2 text-cyan-400 border-b border-cyan-500/20 pb-2 mb-2">
            <Truck size={16} />
            <span className="text-xs uppercase font-mono tracking-wider font-bold">Informasi Pengiriman</span>
          </div>

          {/* GrowID and World Name fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-400 block">
                GrowID Karakter <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={growId}
                  onChange={(e) => setGrowId(e.target.value)}
                  placeholder="Contoh: ZukaPlayer"
                  className={`w-full bg-slate-950/70 border px-4 py-3 rounded-lg text-white font-mono placeholder:text-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent ${
                    errors.growId ? 'border-red-500/60 ring-1 ring-red-500/40' : 'border-white/10'
                  }`}
                />
              </div>
              {errors.growId && (
                <span className="text-[11px] text-red-400 flex items-center gap-1">
                  <AlertTriangle size={11} /> {errors.growId}
                </span>
              )}
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-400 block">
                World Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={worldName}
                onChange={(e) => setWorldName(e.target.value)}
                placeholder="Contoh: ZUKATRADE"
                className={`w-full bg-slate-950/70 border px-4 py-3 rounded-lg text-white font-mono placeholder:text-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent ${
                  errors.worldName ? 'border-red-500/60 ring-1 ring-red-500/40' : 'border-white/10'
                }`}
              />
              {errors.worldName && (
                <span className="text-[11px] text-red-400 flex items-center gap-1">
                  <AlertTriangle size={11} /> {errors.worldName}
                </span>
              )}
            </div>
          </div>

          {/* Delivery Method Selection */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-gray-400 block">Metode Pengantaran</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                onClick={() => setDeliveryMethod('donation_box')}
                className={`p-4 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                  deliveryMethod === 'donation_box'
                    ? 'bg-cyan-950/30 border-cyan-500/50 text-white shadow-lg shadow-cyan-500/5'
                    : 'bg-slate-950/30 border-white/5 text-gray-400 hover:border-white/10'
                }`}
              >
                <div className="p-1.5 rounded-lg bg-slate-900/80 text-cyan-400 border border-white/5 mt-0.5">
                  <Compass size={16} />
                </div>
                <div>
                  <span className="text-sm font-bold block text-white">Donation Box / Display Box</span>
                  <span className="text-[11px] text-gray-400 mt-0.5 block leading-normal">
                    DGL ditaruh langsung ke World Anda (Pastikan World milik Anda & ada Donation/Display Box).
                  </span>
                </div>
              </div>

              <div
                onClick={() => setDeliveryMethod('trade')}
                className={`p-4 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                  deliveryMethod === 'trade'
                    ? 'bg-cyan-950/30 border-cyan-500/50 text-white shadow-lg shadow-cyan-500/5'
                    : 'bg-slate-950/30 border-white/5 text-gray-400 hover:border-white/10'
                }`}
              >
                <div className="p-1.5 rounded-lg bg-slate-900/80 text-cyan-400 border border-white/5 mt-0.5">
                  <MessageSquare size={16} />
                </div>
                <div>
                  <span className="text-sm font-bold block text-white">Ketemuan / Trade In-Game</span>
                  <span className="text-[11px] text-gray-400 mt-0.5 block leading-normal">
                    Admin akan menghubungi Anda via Whatsapp/Discord untuk bertemu langsung dan trade di dalam game.
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Details (WhatsApp / Discord) */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 block">
              Kontak (WhatsApp / ID Discord) <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={contact}
              onChange={(e) => setContact(e.target.value)}
              placeholder="Contoh: WA 08123456789 atau Discord: zuka_player"
              className={`w-full bg-slate-950/70 border px-4 py-3 rounded-lg text-white font-sans placeholder:text-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent ${
                errors.contact ? 'border-red-500/60 ring-1 ring-red-500/40' : 'border-white/10'
              }`}
            />
            {errors.contact ? (
              <span className="text-[11px] text-red-400 flex items-center gap-1">
                <AlertTriangle size={11} /> {errors.contact}
              </span>
            ) : (
              <p className="text-[11px] text-gray-500">Penting agar kami bisa mengonfirmasi transaksi dan pengiriman DGL.</p>
            )}
          </div>

          {/* Optional Notes */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 block">Catatan Tambahan (Opsional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Contoh: Letak donation box di kanan world lock, dsb."
              className="w-full bg-slate-950/70 border border-white/10 px-4 py-3 rounded-lg text-white font-sans placeholder:text-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent resize-none"
            />
          </div>
        </div>

        {/* Right Column: Payment Method Selection & Receipt Info */}
        <div className="lg:col-span-5 space-y-5">
          <div className="flex items-center gap-2 text-cyan-400 border-b border-cyan-500/20 pb-2 mb-2">
            <Wallet size={16} />
            <span className="text-xs uppercase font-mono tracking-wider font-bold">Pilih Cara Pembayaran</span>
          </div>

          {/* Payment Methods Grid */}
          <div className="grid grid-cols-2 gap-2.5">
            {PAYMENT_METHODS.map((pm) => (
              <div
                key={pm.id}
                onClick={() => setPaymentMethod(pm.id)}
                className={`p-3.5 rounded-lg border cursor-pointer transition-all flex flex-col justify-between items-start h-24 ${
                  paymentMethod === pm.id
                    ? 'bg-gradient-to-br from-cyan-950/40 to-blue-950/40 border-cyan-500/80 text-white shadow-lg shadow-cyan-500/5 ring-1 ring-cyan-500/30'
                    : 'bg-slate-950/40 border-white/5 text-gray-400 hover:border-white/10 hover:text-white'
                }`}
              >
                <div className="flex justify-between items-center w-full">
                  <span className={`text-[9px] uppercase font-mono px-1.5 py-0.5 rounded font-bold ${
                    pm.type === 'QRIS' 
                      ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' 
                      : pm.type === 'E-Wallet'
                      ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                      : 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                  }`}>
                    {pm.type}
                  </span>
                  
                  {paymentMethod === pm.id && (
                    <CheckCircle2 size={14} className="text-cyan-400 fill-cyan-950" />
                  )}
                </div>

                <div className="flex items-center gap-2 mt-auto w-full">
                  <img
                    src={pm.logo}
                    alt={pm.name}
                    className="h-5 max-w-[55px] object-contain filter brightness-100 contrast-125"
                    referrerPolicy="no-referrer"
                  />
                  <span className="text-xs font-bold font-sans truncate">{pm.name.split(' ')[0]}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Billing Breakdown panel */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-white/5 space-y-3">
            <span className="text-xs font-bold text-white uppercase font-mono tracking-wider">Rincian Belanja</span>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-gray-400">
                <span>Pembelian DGL:</span>
                <span className="font-mono text-gray-300 font-medium">{quantity} DGL</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>Harga Satuan:</span>
                <span className="font-mono text-gray-300">{formatRupiah(PRICE_PER_DGL)}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>Biaya Transaksi (Admin):</span>
                <span className="text-emerald-400 font-bold uppercase font-mono">FREE</span>
              </div>
              <div className="border-t border-white/5 my-2 pt-2 flex justify-between items-end">
                <span className="text-sm font-bold text-white">Total Tagihan:</span>
                <span className="text-xl font-extrabold text-cyan-400 font-mono">
                  {formatRupiah(totalPrice)}
                </span>
              </div>
            </div>
          </div>

          {/* Quick checkout CTA */}
          <motion.button
            type="submit"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold text-base py-4 rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/10 font-sans"
          >
            <Send size={18} className="stroke-[2.5]" />
            BUAT PESANAN SEKARANG
          </motion.button>
        </div>
      </div>
    </form>
  );
};

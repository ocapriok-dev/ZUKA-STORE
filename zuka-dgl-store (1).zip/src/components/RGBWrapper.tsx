import React from 'react';
import { motion } from 'motion/react';

interface RGBWrapperProps {
  children: React.ReactNode;
  className?: string;
  subtle?: boolean;
  animateHover?: boolean;
  id?: string;
}

export const RGBWrapper: React.FC<RGBWrapperProps> = ({
  children,
  className = '',
  subtle = false,
  animateHover = true,
  id
}) => {
  const wrapperClass = subtle ? 'rgb-border-subtle' : 'rgb-border-wrapper';
  const contentClass = subtle ? 'rgb-border-subtle-content' : 'rgb-border-content';

  return (
    <motion.div
      id={id}
      className={`${wrapperClass} ${className}`}
      whileHover={animateHover ? { scale: 1.015, transition: { duration: 0.2 } } : {}}
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
    >
      <div className={`${contentClass} h-full w-full p-6 text-white`}>
        {children}
      </div>
    </motion.div>
  );
};

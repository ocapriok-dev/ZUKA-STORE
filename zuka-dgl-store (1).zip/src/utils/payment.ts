import { PaymentMethod, Order } from '../types';

export const PRICE_PER_DGL = 27000; // 27k IDR
export const ADMIN_WA_NUMBER = '6285397233609'; // No WA Admin (Format Internasional tanpa + atau spasi)

export const PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: 'qris',
    name: 'QRIS (Semua E-Wallet/Bank)',
    type: 'QRIS',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/a/a2/Logo_QRIS.svg',
    instructions: [
      'Scan kode QRIS yang muncul menggunakan aplikasi pembayaran Anda.',
      'Dukung pembayaran via DANA, OVO, GoPay, ShopeePay, LinkAja, atau Mobile Banking.',
      'Pastikan jumlah transfer tepat sesuai tagihan agar otomatis terverifikasi.',
      'Setelah melakukan pembayaran, gunakan tombol "Konfirmasi Pembayaran" untuk memverifikasi pesanan Anda.'
    ]
  },
  {
    id: 'dana',
    name: 'DANA',
    type: 'E-Wallet',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/7/72/Logo_dana_blue.svg',
    accountNumber: '0812-3456-7890',
    accountName: 'ZUKA STORE OFFICIAL',
    instructions: [
      'Buka aplikasi DANA Anda.',
      'Pilih menu "Kirim" atau "Send".',
      'Pilih "Kirim ke Nomor Telepon".',
      'Masukkan nomor DANA: 0812-3456-7890.',
      'Masukkan nominal sesuai total belanja Anda.',
      'Tulis nomor invoice / GrowID Anda di catatan transfer.',
      'Simpan bukti transfer dan konfirmasi pembayaran di web.'
    ]
  },
  {
    id: 'gopay',
    name: 'GoPay',
    type: 'E-Wallet',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/8/86/Gopay_logo.svg',
    accountNumber: '0812-3456-7890',
    accountName: 'ZUKA STORE OFFICIAL',
    instructions: [
      'Buka aplikasi Gojek / GoPay Anda.',
      'Pilih menu "Bayar" atau "Transfer".',
      'Pilih "Kirim ke nomor HP".',
      'Masukkan nomor GoPay: 0812-3456-7890.',
      'Masukkan nominal sesuai total belanja Anda.',
      'Tulis nomor invoice / GrowID Anda di catatan transfer.',
      'Simpan bukti transfer dan klik konfirmasi.'
    ]
  },
  {
    id: 'ovo',
    name: 'OVO',
    type: 'E-Wallet',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/e/eb/Logo_ovo_purple.svg',
    accountNumber: '0812-3456-7890',
    accountName: 'ZUKA STORE OFFICIAL',
    instructions: [
      'Buka aplikasi OVO Anda.',
      'Pilih menu "Transfer".',
      'Pilih "Ke Sesama OVO".',
      'Masukkan nomor OVO: 0812-3456-7890.',
      'Masukkan nominal sesuai total belanja Anda.',
      'Pastikan nama penerima "ZUKA STORE OFFICIAL" muncul.',
      'Selesaikan pembayaran dan simpan struk transfer.'
    ]
  },
  {
    id: 'bca',
    name: 'Bank BCA',
    type: 'Bank Transfer',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/5/5c/Bank_Central_Asia.svg',
    accountNumber: '8291-0421-44',
    accountName: 'ZUKA ADMIN STORE',
    instructions: [
      'Buka m-BCA atau kunjungi ATM BCA terdekat.',
      'Pilih menu "Transfer" lalu "Ke Rekening BCA".',
      'Masukkan nomor rekening: 8291-0421-44.',
      'Pastikan nama pemilik rekening adalah "ZUKA ADMIN STORE".',
      'Masukkan nominal transfer sesuai total pesanan.',
      'Selesaikan transaksi dan simpan bukti transfer Anda.'
    ]
  },
  {
    id: 'mandiri',
    name: 'Bank Mandiri',
    type: 'Bank Transfer',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/a/ad/Bank_Mandiri_logo_2016.svg',
    accountNumber: '1370-0242-1512',
    accountName: 'ZUKA ADMIN STORE',
    instructions: [
      'Buka Livin\' by Mandiri atau gunakan mesin ATM Mandiri.',
      'Pilih menu "Transfer" lalu "Ke Rekening Mandiri".',
      'Masukkan nomor rekening Mandiri: 1370-0242-1512.',
      'Pastikan penerima adalah "ZUKA ADMIN STORE".',
      'Masukkan nominal transfer sesuai tagihan belanja.',
      'Simpan bukti transfer untuk diunggah jika diperlukan.'
    ]
  }
];

export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

export function generateOrderId(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let orderId = 'ZUKA-';
  for (let i = 0; i < 6; i++) {
    orderId += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return orderId;
}

export const INITIAL_TESTIMONIALS: Omit<Order, 'paymentMethod' | 'deliveryMethod' | 'contact'>[] = [
  {
    id: 'ZUKA-X901A2',
    growId: 'RizkyGT',
    worldName: 'RIZKYSELL',
    quantity: 5,
    pricePerDgl: PRICE_PER_DGL,
    totalPrice: 5 * PRICE_PER_DGL,
    status: 'DELIVERED',
    createdAt: new Date(Date.now() - 4 * 3600 * 1000).toISOString(),
  },
  {
    id: 'ZUKA-M8392B',
    growId: 'Valkyrie01',
    worldName: 'VALKSTORE',
    quantity: 12,
    pricePerDgl: PRICE_PER_DGL,
    totalPrice: 12 * PRICE_PER_DGL,
    status: 'DELIVERED',
    createdAt: new Date(Date.now() - 12 * 3600 * 1000).toISOString(),
  },
  {
    id: 'ZUKA-P2019F',
    growId: 'BintangJaya',
    worldName: 'BINTANGDGL',
    quantity: 2,
    pricePerDgl: PRICE_PER_DGL,
    totalPrice: 2 * PRICE_PER_DGL,
    status: 'DELIVERED',
    createdAt: new Date(Date.now() - 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 'ZUKA-Q8172V',
    growId: 'WelsonGT',
    worldName: 'WELSDROP',
    quantity: 30,
    pricePerDgl: PRICE_PER_DGL,
    totalPrice: 30 * PRICE_PER_DGL,
    status: 'DELIVERED',
    createdAt: new Date(Date.now() - 36 * 3600 * 1000).toISOString(),
  },
  {
    id: 'ZUKA-F1928K',
    growId: 'Chandra99',
    worldName: 'CHANTRADE',
    quantity: 1,
    pricePerDgl: PRICE_PER_DGL,
    totalPrice: 1 * PRICE_PER_DGL,
    status: 'DELIVERED',
    createdAt: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
  }
];
